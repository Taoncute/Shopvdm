<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' - ' . APP_NAME : APP_NAME; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="/css/styles.css">
    <style>
        .alert {
            padding: 15px;
            margin: 20px auto;
            border-radius: 8px;
            max-width: 600px;
            text-align: center;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .user-info {
            background: rgba(255, 255, 255, 0.2);
            padding: 10px 15px;
            margin: 10px 20px;
            border-radius: 8px;
            color: white;
            font-size: 14px;
        }
        .user-info strong {
            display: block;
            margin-bottom: 5px;
        }
        .balance {
            color: #ffd700;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <button class="menu-toggle" onclick="toggleSidebar()">
        <i class="fa-solid fa-bars"></i>
    </button>

    <div class="sidebar" id="sidebar">
        <h2><i class="fa-solid fa-code"></i> <?php echo APP_NAME; ?></h2>
        
        <?php if (Session::isLoggedIn()): 
            $currentUser = Session::getUser();
        ?>
            <div class="user-info">
                <strong><i class="fa-solid fa-user"></i> <?php echo htmlspecialchars($currentUser['username']); ?></strong>
                <span class="balance"><i class="fa-solid fa-wallet"></i> <?php echo number_format($currentUser['balance'], 0, ',', '.'); ?>đ</span>
            </div>
        <?php endif; ?>
        
        <a href="/"><i class="fa-solid fa-home"></i> Trang chủ</a>
        <a href="/products.php"><i class="fa-solid fa-layer-group"></i> Tất cả sản phẩm</a>
        <a href="/products.php?type=free"><i class="fa-solid fa-gift"></i> Miễn phí</a>
        <a href="/products.php?type=paid"><i class="fa-solid fa-sack-dollar"></i> Có phí</a>
        
        <?php if (Session::isLoggedIn()): ?>
            <a href="/cart.php"><i class="fa-solid fa-shopping-cart"></i> Giỏ hàng</a>
            <a href="/topup.php"><i class="fa-solid fa-credit-card"></i> Nạp tiền</a>
            <a href="/orders.php"><i class="fa-solid fa-history"></i> Đơn hàng</a>
            <a href="/profile.php"><i class="fa-solid fa-user-circle"></i> Tài khoản</a>
            
            <?php if (Session::isAdmin()): ?>
                <a href="/admin/"><i class="fa-solid fa-cog"></i> Quản trị</a>
            <?php endif; ?>
            
            <a href="/logout.php"><i class="fa-solid fa-sign-out-alt"></i> Đăng xuất</a>
        <?php else: ?>
            <a href="/login.php"><i class="fa-solid fa-sign-in-alt"></i> Đăng nhập</a>
            <a href="/register.php"><i class="fa-solid fa-user-plus"></i> Đăng ký</a>
        <?php endif; ?>
    </div>

    <div class="main-content">
        <?php
        $successMsg = Session::getFlash('success');
        $errorMsg = Session::getFlash('error');
        
        if ($successMsg): ?>
            <div class="alert alert-success"><?php echo $successMsg; ?></div>
        <?php endif;
        
        if ($errorMsg): ?>
            <div class="alert alert-error"><?php echo $errorMsg; ?></div>
        <?php endif; ?>
