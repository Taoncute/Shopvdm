# HƯỚNG DẪN CẤU HÌNH CLOUDFLARE CHO VDMSHOP.IO.VN

## 🌐 CLOUDFLARE LÀ GÌ?

Cloudflare là dịch vụ CDN (Content Delivery Network) và bảo mật website **MIỄN PHÍ** giúp:

- ⚡ **Tăng tốc độ** website (cache, CDN toàn cầu)
- 🔒 **SSL miễn phí** (HTTPS tự động)
- 🛡️ **Bảo vệ DDoS** (chống tấn công)
- 📊 **Phân tích traffic** (thống kê truy cập)
- 🚀 **Tối ưu hóa** (minify CSS/JS, nén ảnh)

---

## 📋 CHUẨN BỊ

- ✅ Domain: **vdmshop.io.vn** (đã có)
- ✅ Hosting đã setup (Tino Group)
- ✅ Website đã chạy được
- 📧 Email để đăng ký Cloudflare

---

## BƯỚC 1: ĐĂNG KÝ TÀI KHOẢN CLOUDFLARE

### 1.1. Truy cập Cloudflare

1. Mở trình duyệt
2. Truy cập: **https://www.cloudflare.com**
3. Click **Sign Up** (Đăng ký)

### 1.2. Tạo tài khoản

1. Nhập **Email** của bạn
2. Tạo **Password** (mật khẩu mạnh)
3. Click **Create Account**
4. Kiểm tra email → Click link xác nhận

### 1.3. Đăng nhập

1. Đăng nhập với email/password vừa tạo
2. Bạn sẽ thấy dashboard Cloudflare

---

## BƯỚC 2: THÊM DOMAIN VÀO CLOUDFLARE

### 2.1. Add Site

1. Trong dashboard, click **Add a Site**
2. Nhập domain: **vdmshop.io.vn**
3. Click **Add site**

### 2.2. Chọn gói

1. Cloudflare sẽ hiển thị các gói:
   - **Free** - $0/tháng ✅ (Chọn gói này)
   - Pro - $20/tháng
   - Business - $200/tháng
2. Click **Continue** với gói **Free**

### 2.3. Scan DNS Records

1. Cloudflare sẽ tự động quét DNS records hiện tại
2. Đợi 30-60 giây
3. Cloudflare sẽ hiển thị danh sách DNS records tìm được

---

## BƯỚC 3: XÁC NHẬN DNS RECORDS

### 3.1. Kiểm tra records

Cloudflare sẽ hiển thị các records, ví dụ:

| Type | Name | Content | Proxy Status |
|------|------|---------|--------------|
| A | vdmshop.io.vn | 123.45.67.89 | Proxied 🟠 |
| CNAME | www | vdmshop.io.vn | Proxied 🟠 |
| MX | vdmshop.io.vn | mail.tino.vn | DNS only ⚪ |

### 3.2. Bật Proxy (quan trọng!)

1. Đảm bảo records **A** và **CNAME** có icon **🟠 Proxied**
2. Nếu là **⚪ DNS only**, click vào icon để chuyển sang **Proxied**
3. **Proxied** = Traffic đi qua Cloudflare (có CDN, SSL, bảo mật)

### 3.3. Thêm record www (nếu chưa có)

1. Click **Add record**
2. Điền:
   - Type: **CNAME**
   - Name: **www**
   - Target: **vdmshop.io.vn**
   - Proxy status: **Proxied** 🟠
3. Click **Save**

### 3.4. Continue

1. Kiểm tra lại tất cả records
2. Click **Continue**

---

## BƯỚC 4: THAY ĐỔI NAMESERVERS

### 4.1. Lấy Nameservers từ Cloudflare

Cloudflare sẽ hiển thị 2 nameservers, ví dụ:

```
blake.ns.cloudflare.com
lola.ns.cloudflare.com
```

**GHI LẠI 2 NAMESERVERS NÀY!**

### 4.2. Đổi Nameservers tại Tino Group

#### Cách 1: Qua Client Area Tino

1. Đăng nhập: **https://tino.vn/clientarea**
2. Vào **Domains** → **My Domains**
3. Click vào domain **vdmshop.io.vn**
4. Click tab **Nameservers** hoặc **Quản lý DNS**
5. Chọn **Use custom nameservers**
6. Xóa nameservers cũ:
   - ~~ns1.tino.vn~~
   - ~~ns2.tino.vn~~
7. Nhập nameservers mới từ Cloudflare:
   - Nameserver 1: `blake.ns.cloudflare.com` (thay bằng của bạn)
   - Nameserver 2: `lola.ns.cloudflare.com` (thay bằng của bạn)
8. Click **Save** hoặc **Change Nameservers**

#### Cách 2: Liên hệ Support Tino

Nếu không tự đổi được:

1. Gửi ticket support tại: https://tino.vn/submitticket.php
2. Hoặc chat live support
3. Yêu cầu: "Xin đổi nameservers domain vdmshop.io.vn sang Cloudflare"
4. Cung cấp 2 nameservers từ Cloudflare

### 4.3. Xác nhận trên Cloudflare

1. Quay lại Cloudflare
2. Click **Done, check nameservers**
3. Cloudflare sẽ bắt đầu kiểm tra

---

## BƯỚC 5: ĐỢI ACTIVE (QUAN TRỌNG!)

### 5.1. Thời gian chờ

- **Thời gian:** 5 phút - 24 giờ (thường 1-2 giờ)
- **Lý do:** DNS cần thời gian lan truyền toàn cầu

### 5.2. Kiểm tra trạng thái

1. Cloudflare sẽ gửi email khi active
2. Hoặc vào dashboard → Status sẽ chuyển từ **Pending** → **Active** ✅

### 5.3. Trong lúc chờ

- Website vẫn hoạt động bình thường
- Không cần làm gì thêm
- Chờ email từ Cloudflare

---

## BƯỚC 6: CẤU HÌNH SSL (SAU KHI ACTIVE)

### 6.1. Vào SSL/TLS Settings

1. Trong dashboard Cloudflare
2. Click vào domain **vdmshop.io.vn**
3. Sidebar trái → Click **SSL/TLS**

### 6.2. Chọn chế độ SSL

1. Chọn **Full** hoặc **Full (strict)**
   - **Full**: Khuyến nghị nếu hosting có SSL
   - **Flexible**: Nếu hosting chưa có SSL (không an toàn lắm)
2. Click để chọn

### 6.3. Bật Always Use HTTPS

1. Vào tab **Edge Certificates**
2. Tìm **Always Use HTTPS**
3. Bật ON (toggle sang phải)
4. Website sẽ tự động redirect HTTP → HTTPS

### 6.4. Bật Automatic HTTPS Rewrites

1. Trong cùng trang **Edge Certificates**
2. Tìm **Automatic HTTPS Rewrites**
3. Bật ON
4. Tự động sửa link HTTP thành HTTPS

---

## BƯỚC 7: TỐI ƯU HÓA HIỆU NĂNG

### 7.1. Bật Auto Minify

1. Sidebar → Click **Speed** → **Optimization**
2. Tìm **Auto Minify**
3. Tick chọn:
   - ✅ JavaScript
   - ✅ CSS
   - ✅ HTML
4. Click **Save**

### 7.2. Bật Brotli

1. Trong cùng trang **Optimization**
2. Tìm **Brotli**
3. Bật ON
4. Nén file tốt hơn Gzip

### 7.3. Cấu hình Caching

1. Sidebar → Click **Caching** → **Configuration**
2. **Caching Level**: Chọn **Standard**
3. **Browser Cache TTL**: Chọn **4 hours** hoặc **1 day**
4. Click **Save**

### 7.4. Tạo Page Rules (Tùy chọn)

1. Sidebar → Click **Rules** → **Page Rules**
2. Click **Create Page Rule**
3. URL: `vdmshop.io.vn/*`
4. Settings:
   - **Cache Level**: Cache Everything
   - **Edge Cache TTL**: 1 month
5. Click **Save and Deploy**

---

## BƯỚC 8: CẤU HÌNH BẢO MẬT

### 8.1. Bật Bot Fight Mode

1. Sidebar → Click **Security** → **Bots**
2. **Bot Fight Mode**: Bật ON
3. Chống bot spam tự động

### 8.2. Cấu hình Security Level

1. Sidebar → Click **Security** → **Settings**
2. **Security Level**: Chọn **Medium**
3. Cân bằng giữa bảo mật và trải nghiệm

### 8.3. Bật Browser Integrity Check

1. Trong cùng trang **Settings**
2. **Browser Integrity Check**: Bật ON
3. Chặn traffic đáng ngờ

---

## BƯỚC 9: KIỂM TRA WEBSITE

### 9.1. Kiểm tra SSL

1. Truy cập: **https://vdmshop.io.vn**
2. Kiểm tra icon khóa 🔒 trên thanh địa chỉ
3. Click vào khóa → Xem certificate
4. Issuer: Cloudflare Inc

### 9.2. Kiểm tra tốc độ

1. Truy cập: **https://www.webpagetest.org**
2. Nhập: vdmshop.io.vn
3. Click **Start Test**
4. Xem kết quả tốc độ

### 9.3. Kiểm tra SSL Score

1. Truy cập: **https://www.ssllabs.com/ssltest/**
2. Nhập: vdmshop.io.vn
3. Click **Submit**
4. Mục tiêu: Điểm A hoặc A+

---

## BƯỚC 10: CẤU HÌNH NÂNG CAO (TÙY CHỌN)

### 10.1. Firewall Rules

Chặn traffic từ quốc gia cụ thể:

1. **Security** → **WAF** → **Firewall rules**
2. **Create rule**
3. Rule name: `Block spam countries`
4. Expression:
   ```
   (ip.geoip.country in {"CN" "RU"})
   ```
5. Action: **Block**
6. Click **Deploy**

### 10.2. Rate Limiting

Giới hạn request:

1. **Security** → **WAF** → **Rate limiting rules**
2. **Create rule**
3. Limit: 100 requests per minute
4. Click **Deploy**

### 10.3. Email Obfuscation

Ẩn email khỏi bot spam:

1. **Scrape Shield** → **Email Address Obfuscation**
2. Bật ON

---

## ✅ CHECKLIST SAU KHI CẤU HÌNH

- [ ] Nameservers đã đổi sang Cloudflare
- [ ] Status: Active ✅
- [ ] SSL: Full mode
- [ ] Always Use HTTPS: ON
- [ ] Auto Minify: ON (JS, CSS, HTML)
- [ ] Brotli: ON
- [ ] Bot Fight Mode: ON
- [ ] Website truy cập được qua HTTPS
- [ ] Icon khóa 🔒 hiển thị
- [ ] Tốc độ load nhanh hơn

---

## 🎯 LỢI ÍCH SAU KHI DÙNG CLOUDFLARE

### Trước Cloudflare:
- ❌ HTTP (không bảo mật)
- ❌ Tốc độ chậm
- ❌ Dễ bị tấn công DDoS
- ❌ Không có CDN

### Sau Cloudflare:
- ✅ HTTPS (SSL miễn phí)
- ✅ Tốc độ nhanh (CDN toàn cầu)
- ✅ Chống DDoS tự động
- ✅ Tối ưu hóa tự động
- ✅ Phân tích traffic
- ✅ Bảo mật tốt hơn

---

## 📊 THEO DÕI VÀ PHÂN TÍCH

### Dashboard Analytics

1. Vào **Analytics & Logs** → **Traffic**
2. Xem:
   - Requests (lượt truy cập)
   - Bandwidth (băng thông)
   - Threats blocked (mối đe dọa chặn)
   - Countries (quốc gia truy cập)

### Email Reports

1. **Notifications** → **Add**
2. Chọn nhận báo cáo hàng tuần
3. Theo dõi traffic và bảo mật

---

## 🐛 XỬ LÝ LỖI

### Lỗi: Website không truy cập được

**Nguyên nhân:** DNS chưa lan truyền

**Giải pháp:**
- Đợi thêm vài giờ
- Xóa cache DNS: `ipconfig /flushdns` (Windows)
- Thử truy cập từ mạng khác

### Lỗi: SSL Error

**Nguyên nhân:** SSL mode không đúng

**Giải pháp:**
- Đổi SSL mode: Full → Flexible
- Hoặc cài SSL trên hosting trước

### Lỗi: Redirect Loop

**Nguyên nhân:** Cả hosting và Cloudflare đều redirect HTTPS

**Giải pháp:**
- Tắt redirect HTTPS trong .htaccess
- Chỉ dùng Cloudflare redirect

---

## 📞 HỖ TRỢ

**Cloudflare Community:**
- https://community.cloudflare.com

**Cloudflare Docs:**
- https://developers.cloudflare.com

**Tino Group Support:**
- Hotline: 1900 6680
- Email: support@tino.org

---

## 🎉 HOÀN TẤT!

Website **vdmshop.io.vn** của bạn giờ đã:

- ⚡ Nhanh hơn với CDN Cloudflare
- 🔒 Bảo mật với SSL miễn phí
- 🛡️ An toàn với DDoS protection
- 🚀 Tối ưu hóa tự động

**Chúc mừng bạn! 🎊**

---

## 📝 GHI CHÚ

**Thông tin Cloudflare (GHI LẠI):**
```
Email: _________________
Password: _________________
Nameserver 1: _________________
Nameserver 2: _________________
```

**Thời gian setup:** 30-60 phút (bao gồm thời gian chờ DNS)
