# ✅ CHECKLIST DEPLOY VANHSHOP LÊN TINO GROUP

## 📌 CHUẨN BỊ

- [ ] Có domain: **vdmshop.io.vn** ✅ (Đã có)
- [ ] Mua hosting Tino Group (PHP 7.4+, MySQL)
- [ ] Có file: **vanhshop_final.zip**
- [ ] Có thông tin đăng nhập cPanel

---

## 🚀 CÁC BƯỚC THỰC HIỆN

### BƯỚC 1: ĐĂNG NHẬP CPANEL
- [ ] Truy cập: https://tino.vn:2083
- [ ] Đăng nhập với username/password từ email Tino

### BƯỚC 2: UPLOAD VÀ GIẢI NÉN
- [ ] Mở File Manager
- [ ] Vào thư mục public_html
- [ ] Upload file vanhshop_final.zip
- [ ] Extract (giải nén) file zip
- [ ] Di chuyển file từ shop_online/public/ ra public_html/
- [ ] Xóa thư mục shop_online rỗng

### BƯỚC 3: TẠO DATABASE
- [ ] Vào MySQL® Databases
- [ ] Tạo database: `shop_online`
- [ ] Ghi lại tên đầy đủ: `username_shop_online`
- [ ] Tạo user: `shop_user`
- [ ] Tạo mật khẩu mạnh và GHI LẠI
- [ ] Ghi lại username đầy đủ: `username_shop_user`
- [ ] Gán user vào database với ALL PRIVILEGES

### BƯỚC 4: IMPORT DATABASE
- [ ] Vào phpMyAdmin
- [ ] Chọn database vừa tạo
- [ ] Click tab Import
- [ ] Chọn file database_schema.sql
- [ ] Click Go
- [ ] Kiểm tra có 8 tables

### BƯỚC 5: CẤU HÌNH .ENV
- [ ] Mở File Manager
- [ ] Edit file .env
- [ ] Cập nhật DB_NAME (có prefix username)
- [ ] Cập nhật DB_USER (có prefix username)
- [ ] Cập nhật DB_PASS (mật khẩu đã ghi)
- [ ] Cập nhật APP_URL=https://vdmshop.io.vn
- [ ] Save Changes

### BƯỚC 6: CẤP QUYỀN
- [ ] Cấp quyền 755 cho thư mục uploads
- [ ] Kiểm tra file .htaccess đã có

### BƯỚC 7: CÀI SSL
- [ ] Vào SSL/TLS Status
- [ ] Run AutoSSL cho domain
- [ ] Đợi 5-10 phút

### BƯỚC 8: KIỂM TRA
- [ ] Truy cập https://vdmshop.io.vn
- [ ] Website hiển thị
- [ ] CSS hiển thị đúng
- [ ] Hình ảnh hiển thị
- [ ] Đăng nhập admin (admin/admin123)
- [ ] Xem sản phẩm
- [ ] Thử đăng ký tài khoản
- [ ] Thử giỏ hàng
- [ ] Kiểm tra QR code
- [ ] Kiểm tra Telegram

### BƯỚC 9: BẢO MẬT
- [ ] Đổi mật khẩu admin NGAY
- [ ] Xóa file database_schema.sql
- [ ] Xóa các file .md không cần thiết
- [ ] Xóa file zip

### BƯỚC 10: HOÀN TẤT
- [ ] Backup database
- [ ] Ghi lại thông tin đăng nhập
- [ ] Test đầy đủ tính năng
- [ ] Sẵn sàng kinh doanh! 🎉

---

## 📝 GHI CHÚ QUAN TRỌNG

**Thông tin Database (GHI LẠI):**
```
DB_HOST: localhost
DB_NAME: _________________ (vd: tinouser_shop_online)
DB_USER: _________________ (vd: tinouser_shop_user)
DB_PASS: _________________ (mật khẩu đã tạo)
```

**Thông tin Admin:**
```
Username: admin
Password cũ: admin123
Password mới: _________________ (sau khi đổi)
```

**Website:**
```
URL: https://vdmshop.io.vn
cPanel: https://tino.vn:2083
```

---

## 🆘 HỖ TRỢ

**Tino Group:**
- Hotline: 1900 6680
- Email: support@tino.org
- Chat: https://tino.vn

**Tài liệu:**
- HUONG_DAN_DEPLOY_TINO.md (chi tiết từng bước)
- HUONG_DAN_SU_DUNG.md (hướng dẫn sử dụng)

---

**Thời gian ước tính: 15-30 phút**

**Chúc bạn thành công! 🚀**
