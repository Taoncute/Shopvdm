# HƯỚNG DẪN SỬ DỤNG VANHSHOP

## MỤC LỤC

1. [Giới thiệu](#giới-thiệu)
2. [Cài đặt](#cài-đặt)
3. [Cấu hình](#cấu-hình)
4. [Sử dụng cho người dùng](#sử-dụng-cho-người-dùng)
5. [Sử dụng cho Admin](#sử-dụng-cho-admin)
6. [Cấu hình VietQR](#cấu-hình-vietqr)
7. [Cấu hình Telegram Bot](#cấu-hình-telegram-bot)
8. [Xử lý sự cố](#xử-lý-sự-cố)

---

## GIỚI THIỆU

VanhShop là hệ thống shop online bán mã nguồn (code) với các tính năng:
- Quản lý sản phẩm miễn phí và có phí
- Giỏ hàng và thanh toán
- Thanh toán qua VietQR (tạo mã QR tự động)
- Nạp tiền vào tài khoản
- Thông báo qua Telegram Bot
- Lịch sử đơn hàng và giao dịch

---

## CÀI ĐẶT

### Bước 1: Cài đặt môi trường

**Trên Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install php php-mysql php-mbstring php-curl php-gd mysql-server
```

**Trên Windows:**
- Cài đặt XAMPP hoặc WAMP
- Đảm bảo PHP >= 7.4 và MySQL >= 5.7

### Bước 2: Import Database

```bash
# Đăng nhập MySQL
mysql -u root -p

# Import database
mysql -u root -p < database_schema.sql
```

Hoặc dùng phpMyAdmin:
1. Mở phpMyAdmin
2. Tạo database mới tên `shop_online`
3. Import file `database_schema.sql`

### Bước 3: Cấu hình kết nối Database

Chỉnh sửa file `.env`:

```env
DB_HOST=localhost
DB_NAME=shop_online
DB_USER=root
DB_PASS=your_password_here
```

### Bước 4: Khởi động server

**Sử dụng PHP built-in server:**
```bash
cd public
php -S localhost:8000 index.php
```

**Sử dụng Apache:**
- Copy toàn bộ project vào `/var/www/html/` hoặc `htdocs/`
- Cấu hình DocumentRoot trỏ đến thư mục `public/`
- Restart Apache

Truy cập: `http://localhost:8000`

---

## CẤU HÌNH

### File .env

```env
# Cấu hình Database
DB_HOST=localhost
DB_NAME=shop_online
DB_USER=root
DB_PASS=

# Cấu hình ứng dụng
APP_NAME=VanhShop
APP_URL=http://localhost:8000

# Cấu hình VietQR
VIETQR_BANK_ID=970422          # Mã ngân hàng (MB Bank)
VIETQR_ACCOUNT_NO=0123456789   # Số tài khoản của bạn
VIETQR_ACCOUNT_NAME=NGUYEN VAN A  # Tên chủ tài khoản
VIETQR_TEMPLATE=compact        # Template QR code

# Cấu hình Telegram Bot
TELEGRAM_BOT_TOKEN=123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11
TELEGRAM_ADMIN_CHAT_ID=123456789
```

### Danh sách mã ngân hàng phổ biến

| Ngân hàng | Mã Bank ID |
|-----------|------------|
| Vietcombank | 970436 |
| Techcombank | 970407 |
| BIDV | 970418 |
| VietinBank | 970415 |
| MB Bank | 970422 |
| ACB | 970416 |
| Agribank | 970405 |
| TPBank | 970423 |
| Sacombank | 970403 |
| VPBank | 970432 |

---

## SỬ DỤNG CHO NGƯỜI DÙNG

### 1. Đăng ký tài khoản

1. Truy cập trang chủ
2. Click "Đăng ký" trên sidebar
3. Điền thông tin:
   - Tên đăng nhập (tối thiểu 3 ký tự)
   - Email hợp lệ
   - Họ và tên (tùy chọn)
   - Mật khẩu (tối thiểu 6 ký tự)
   - Xác nhận mật khẩu
4. Click "Đăng ký"

### 2. Đăng nhập

1. Click "Đăng nhập" trên sidebar
2. Nhập tên đăng nhập hoặc email
3. Nhập mật khẩu
4. Chọn "Ghi nhớ đăng nhập" (tùy chọn)
5. Click "Đăng nhập"

### 3. Xem và mua sản phẩm

**Xem sản phẩm:**
- Trang chủ: Hiển thị tất cả sản phẩm
- Miễn phí: Chỉ sản phẩm miễn phí
- Có phí: Chỉ sản phẩm có phí

**Sản phẩm miễn phí:**
- Click "Tải xuống" để tải trực tiếp

**Sản phẩm có phí:**
- Click "Thêm vào giỏ" để thêm vào giỏ hàng

### 4. Giỏ hàng

1. Click "Giỏ hàng" trên sidebar
2. Xem danh sách sản phẩm đã thêm
3. Cập nhật số lượng (nếu cần)
4. Xóa sản phẩm không mong muốn
5. Click "Tiến hành thanh toán"

### 5. Thanh toán

**Chọn phương thức thanh toán:**

**A. Thanh toán bằng số dư:**
- Chọn "Thanh toán bằng số dư tài khoản"
- Click "Xác nhận thanh toán"
- Hệ thống tự động trừ tiền và hoàn tất đơn hàng

**B. Thanh toán qua VietQR:**
- Chọn "Thanh toán qua VietQR"
- Click "Xác nhận thanh toán"
- Hệ thống tạo mã QR
- Quét mã QR bằng app ngân hàng
- Chuyển khoản với nội dung đúng như hiển thị
- Click "Tôi đã thanh toán"

### 6. Nạp tiền vào tài khoản

1. Click "Nạp tiền" trên sidebar
2. Chọn mệnh giá có sẵn hoặc nhập số tiền tùy chọn
3. Click "Tạo mã QR thanh toán"
4. Quét mã QR và chuyển khoản
5. Đợi hệ thống xác nhận (tự động hoặc thủ công)

### 7. Xem đơn hàng

1. Click "Đơn hàng" trên sidebar
2. Xem danh sách tất cả đơn hàng
3. Click "Xem" để xem chi tiết
4. Tải sản phẩm sau khi thanh toán thành công

### 8. Quản lý tài khoản

1. Click "Tài khoản" trên sidebar
2. Xem số dư hiện tại
3. Cập nhật thông tin cá nhân
4. Thêm Telegram Chat ID để nhận thông báo
5. Đổi mật khẩu

---

## SỬ DỤNG CHO ADMIN

### Đăng nhập Admin

**Tài khoản mặc định:**
- Username: `admin`
- Password: `admin123`

**⚠️ LƯU Ý: Đổi mật khẩu ngay sau lần đăng nhập đầu tiên!**

### Quản lý sản phẩm

**Thêm sản phẩm mới:**
1. Truy cập Admin Panel
2. Click "Quản lý sản phẩm"
3. Click "Thêm sản phẩm mới"
4. Điền thông tin:
   - Tên sản phẩm
   - Mô tả
   - Giá (0 nếu miễn phí)
   - Hình ảnh
   - Link tải (nếu có)
5. Click "Lưu"

**Chỉnh sửa sản phẩm:**
1. Tìm sản phẩm cần sửa
2. Click "Sửa"
3. Cập nhật thông tin
4. Click "Lưu"

**Xóa sản phẩm:**
1. Tìm sản phẩm cần xóa
2. Click "Xóa"
3. Xác nhận xóa

### Quản lý đơn hàng

1. Xem danh sách tất cả đơn hàng
2. Lọc theo trạng thái
3. Xem chi tiết đơn hàng
4. Xác nhận thanh toán thủ công (nếu cần)

### Quản lý người dùng

1. Xem danh sách người dùng
2. Xem thông tin chi tiết
3. Cập nhật số dư (nếu cần)
4. Khóa/Mở khóa tài khoản

---

## CẤU HÌNH VIETQR

### Bước 1: Chuẩn bị thông tin

Bạn cần có:
- Tài khoản ngân hàng hỗ trợ VietQR
- Số tài khoản
- Tên chủ tài khoản (viết hoa, không dấu)
- Mã ngân hàng (Bank ID)

### Bước 2: Cập nhật file .env

```env
VIETQR_BANK_ID=970422
VIETQR_ACCOUNT_NO=0123456789
VIETQR_ACCOUNT_NAME=NGUYEN VAN A
```

### Bước 3: Test VietQR

1. Tạo một đơn hàng test
2. Chọn thanh toán qua VietQR
3. Kiểm tra mã QR có hiển thị đúng không
4. Thử quét bằng app ngân hàng

### Lưu ý

- Tên chủ tài khoản phải **VIẾT HOA** và **KHÔNG DẤU**
- Ví dụ: "Nguyễn Văn A" → "NGUYEN VAN A"
- Nội dung chuyển khoản phải giữ nguyên để hệ thống nhận diện

---

## CẤU HÌNH TELEGRAM BOT

### Bước 1: Tạo Telegram Bot

1. Mở Telegram, tìm [@BotFather](https://t.me/BotFather)
2. Gửi lệnh `/newbot`
3. Đặt tên cho bot (ví dụ: VanhShop Bot)
4. Đặt username cho bot (phải kết thúc bằng `bot`)
5. Lưu Bot Token (dạng: `123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11`)

### Bước 2: Lấy Chat ID

**Cho Admin:**
1. Tìm [@userinfobot](https://t.me/userinfobot) trên Telegram
2. Gửi bất kỳ tin nhắn nào
3. Bot sẽ trả về Chat ID của bạn
4. Lưu Chat ID này

**Cho người dùng:**
1. Đăng nhập vào website
2. Vào trang "Tài khoản"
3. Lấy Chat ID từ @userinfobot
4. Nhập vào ô "Telegram Chat ID"
5. Lưu thay đổi

### Bước 3: Cập nhật file .env

```env
TELEGRAM_BOT_TOKEN=123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11
TELEGRAM_ADMIN_CHAT_ID=123456789
```

### Bước 4: Test Telegram Bot

1. Tạo một đơn hàng test
2. Kiểm tra xem có nhận được thông báo không
3. Nếu không nhận được:
   - Kiểm tra Bot Token
   - Kiểm tra Chat ID
   - Đảm bảo đã start bot (gửi `/start` cho bot)

### Các loại thông báo

**Cho người dùng:**
- Đơn hàng mới được tạo
- Thanh toán thành công
- Nạp tiền thành công

**Cho Admin:**
- Có đơn hàng mới
- Có thanh toán mới
- Có giao dịch nạp tiền mới

---

## XỬ LÝ SỰ CỐ

### 1. Không kết nối được database

**Lỗi:** `Connection Error: SQLSTATE[HY000] [2002]`

**Giải pháp:**
```bash
# Kiểm tra MySQL đã chạy chưa
sudo service mysql status

# Khởi động MySQL
sudo service mysql start

# Kiểm tra thông tin kết nối trong .env
```

### 2. Không hiển thị CSS/Images

**Nguyên nhân:** Đường dẫn file không đúng

**Giải pháp:**
- Kiểm tra file có tồn tại trong thư mục `public/css/` và `public/assets/`
- Kiểm tra quyền truy cập file: `chmod 644 public/css/*`

### 3. Không tạo được mã QR

**Nguyên nhân:** Chưa cấu hình VietQR

**Giải pháp:**
- Kiểm tra file `.env` đã có đầy đủ thông tin VietQR chưa
- Test URL QR: `https://img.vietqr.io/image/970422-0123456789-compact.jpg?amount=10000`

### 4. Không nhận được thông báo Telegram

**Nguyên nhân:** Chưa cấu hình Telegram Bot hoặc Chat ID sai

**Giải pháp:**
- Kiểm tra Bot Token trong `.env`
- Kiểm tra Chat ID
- Đảm bảo đã gửi `/start` cho bot
- Test gửi tin nhắn thủ công:
  ```bash
  curl -X POST "https://api.telegram.org/bot<BOT_TOKEN>/sendMessage" \
       -d "chat_id=<CHAT_ID>" \
       -d "text=Test message"
  ```

### 5. Lỗi 404 Not Found

**Nguyên nhân:** Routing không đúng

**Giải pháp:**
- Đảm bảo đang chạy PHP server với `index.php` làm router:
  ```bash
  php -S localhost:8000 index.php
  ```
- Nếu dùng Apache, cấu hình `.htaccess`

### 6. Session không hoạt động

**Nguyên nhân:** Quyền ghi thư mục session

**Giải pháp:**
```bash
# Kiểm tra thư mục session
php -i | grep session.save_path

# Cấp quyền ghi
sudo chmod 777 /var/lib/php/sessions
```

### 7. Upload file không hoạt động

**Giải pháp:**
```bash
# Tạo thư mục uploads
mkdir -p public/uploads

# Cấp quyền ghi
chmod 777 public/uploads
```

---

## TIPS & TRICKS

### 1. Tăng tốc độ website

- Bật OPcache trong PHP
- Sử dụng CDN cho assets
- Minify CSS/JS
- Tối ưu hóa hình ảnh

### 2. Bảo mật

- Đổi mật khẩu admin ngay lập tức
- Sử dụng HTTPS trong production
- Cập nhật PHP và MySQL thường xuyên
- Backup database định kỳ

### 3. Backup

```bash
# Backup database
mysqldump -u root -p shop_online > backup_$(date +%Y%m%d).sql

# Backup files
tar -czf backup_files_$(date +%Y%m%d).tar.gz shop_online/
```

### 4. Monitoring

- Theo dõi log: `/tmp/php_server.log`
- Kiểm tra MySQL slow query log
- Sử dụng Google Analytics

---

## HỖ TRỢ

Nếu gặp vấn đề không giải quyết được, vui lòng:

1. Kiểm tra log lỗi
2. Đọc lại hướng dẫn
3. Tìm kiếm trên Google
4. Liên hệ developer

---

**Chúc bạn sử dụng VanhShop thành công! 🎉**
