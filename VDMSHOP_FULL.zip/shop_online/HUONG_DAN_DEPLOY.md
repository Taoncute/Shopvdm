# HƯỚNG DẪN DEPLOY VANHSHOP LÊN HOSTING

## 📋 CHUẨN BỊ

Bạn cần có:
- ✅ Domain (đã mua)
- ✅ Hosting hỗ trợ PHP 7.4+ và MySQL 5.7+
- ✅ File `vanhshop_configured.zip`
- ✅ Thông tin đăng nhập hosting (cPanel/DirectAdmin)

---

## 🚀 BƯỚC 1: UPLOAD FILE LÊN HOSTING

### Cách 1: Qua cPanel File Manager

1. Đăng nhập vào **cPanel** của hosting
2. Mở **File Manager**
3. Vào thư mục `public_html` (hoặc `www`, `htdocs`)
4. Click **Upload**
5. Chọn file `vanhshop_configured.zip` và upload
6. Sau khi upload xong, click chuột phải vào file zip
7. Chọn **Extract** để giải nén
8. Di chuyển tất cả file từ thư mục `shop_online/public/` ra ngoài `public_html`

### Cách 2: Qua FTP (FileZilla)

1. Tải và cài đặt **FileZilla Client**
2. Kết nối FTP với thông tin:
   - Host: ftp.domain-cua-ban.com
   - Username: username FTP
   - Password: password FTP
   - Port: 21
3. Upload file zip vào thư mục `public_html`
4. Giải nén trên cPanel File Manager

---

## 🗄️ BƯỚC 2: TẠO DATABASE

### Trên cPanel:

1. Vào **MySQL Databases**
2. Tạo database mới:
   - Database Name: `shop_online` (hoặc tên khác)
   - Click **Create Database**
3. Tạo user mới:
   - Username: `shop_user` (hoặc tên khác)
   - Password: Tạo mật khẩu mạnh
   - Click **Create User**
4. Gán quyền:
   - Chọn user vừa tạo
   - Chọn database vừa tạo
   - Click **Add**
   - Chọn **ALL PRIVILEGES**
   - Click **Make Changes**
5. **Lưu lại thông tin:**
   - Database name: `cpanel_user_shop_online`
   - Database user: `cpanel_user_shop_user`
   - Database password: `mật_khẩu_vừa_tạo`
   - Database host: `localhost`

---

## 📊 BƯỚC 3: IMPORT DATABASE

### Qua phpMyAdmin:

1. Vào **phpMyAdmin** trong cPanel
2. Chọn database vừa tạo ở sidebar bên trái
3. Click tab **Import**
4. Click **Choose File**
5. Chọn file `database_schema.sql` (trong thư mục shop_online)
6. Click **Go** để import
7. Đợi import hoàn tất (sẽ thấy thông báo thành công)

---

## ⚙️ BƯỚC 4: CẤU HÌNH FILE .ENV

1. Mở **File Manager** trong cPanel
2. Vào thư mục chứa website
3. Tìm file `.env`
4. Click chuột phải → **Edit**
5. Cập nhật thông tin database:

```env
# Database Configuration
DB_HOST=localhost
DB_NAME=cpanel_user_shop_online
DB_USER=cpanel_user_shop_user
DB_PASS=mật_khẩu_database_của_bạn

# App Configuration
APP_NAME=VanhShop
APP_URL=https://domain-cua-ban.com
APP_ENV=production

# VietQR Configuration (ĐÃ CÓ SẴN)
VIETQR_BANK_ID=970423
VIETQR_ACCOUNT_NO=22523112009
VIETQR_ACCOUNT_NAME=DUONG VINH MANH
VIETQR_TEMPLATE=compact

# Telegram Bot Configuration (ĐÃ CÓ SẴN)
TELEGRAM_BOT_TOKEN=8435659667:AAGK1zWRbkc1Y-XG6uaFz0nu1wW9k9WNH0Q
TELEGRAM_ADMIN_CHAT_ID=7803422532

# Security
SESSION_LIFETIME=7200
CSRF_TOKEN_NAME=csrf_token
```

6. Click **Save Changes**

---

## 📁 BƯỚC 5: CẤU TRÚC THỨ MỤC

Website cần cấu trúc như sau trong `public_html`:

```
public_html/
├── index.php          # File chính
├── login.php
├── register.php
├── products.php
├── cart.php
├── checkout.php
├── payment.php
├── orders.php
├── topup.php
├── profile.php
├── logout.php
├── assets/            # Hình ảnh sản phẩm
├── css/               # File CSS
├── js/                # File JavaScript
├── uploads/           # Thư mục upload
├── .htaccess          # Cần tạo mới
└── (các thư mục app, includes...)
```

### Tạo file .htaccess:

Tạo file `.htaccess` trong `public_html` với nội dung:

```apache
# Enable Rewrite Engine
RewriteEngine On

# Redirect to HTTPS (nếu có SSL)
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# Protect .env file
<Files .env>
    Order allow,deny
    Deny from all
</Files>

# PHP Settings
php_value upload_max_filesize 20M
php_value post_max_size 20M
php_value max_execution_time 300
php_value max_input_time 300

# Disable directory browsing
Options -Indexes

# Custom Error Pages
ErrorDocument 404 /404.php
ErrorDocument 500 /500.php
```

---

## 🔒 BƯỚC 6: CẤP QUYỀN THỨ MỤC

Cấp quyền ghi cho thư mục uploads:

1. Trong File Manager, click chuột phải vào thư mục `uploads`
2. Chọn **Change Permissions**
3. Đặt quyền: **755** hoặc **777**
4. Click **Change Permissions**

---

## 🔐 BƯỚC 7: BẢO MẬT

### Đổi mật khẩu Admin:

1. Truy cập website: `https://domain-cua-ban.com`
2. Đăng nhập với:
   - Username: `admin`
   - Password: `admin123`
3. Vào trang **Tài khoản**
4. Đổi mật khẩu ngay lập tức!

### Cài đặt SSL (HTTPS):

1. Trong cPanel, vào **SSL/TLS Status**
2. Click **Run AutoSSL** (miễn phí)
3. Đợi SSL được cài đặt
4. Website sẽ chạy trên HTTPS

---

## ✅ BƯỚC 8: KIỂM TRA

### Checklist kiểm tra:

- [ ] Truy cập được website: `https://domain-cua-ban.com`
- [ ] Đăng nhập admin thành công
- [ ] Hiển thị danh sách sản phẩm
- [ ] Đăng ký tài khoản mới được
- [ ] Thêm sản phẩm vào giỏ hàng
- [ ] Tạo đơn hàng test
- [ ] Mã QR VietQR hiển thị đúng thông tin
- [ ] Nhận thông báo Telegram
- [ ] CSS hiển thị đúng
- [ ] Hình ảnh sản phẩm hiển thị

---

## 🐛 XỬ LÝ LỖI THƯỜNG GẶP

### Lỗi 500 Internal Server Error

**Nguyên nhân:** File .htaccess hoặc quyền file

**Giải pháp:**
1. Xóa file .htaccess tạm thời
2. Kiểm tra lại quyền file (644 cho file, 755 cho thư mục)
3. Kiểm tra PHP version (cần 7.4+)

### Lỗi kết nối Database

**Nguyên nhân:** Thông tin database sai

**Giải pháp:**
1. Kiểm tra lại file `.env`
2. Đảm bảo database name có prefix (vd: `cpanel_user_shop_online`)
3. Kiểm tra username và password database

### CSS không hiển thị

**Nguyên nhân:** Đường dẫn file sai

**Giải pháp:**
1. Kiểm tra thư mục `css/` có file `styles.css`
2. Kiểm tra quyền file: 644
3. Clear cache trình duyệt (Ctrl + F5)

### Hình ảnh không hiển thị

**Nguyên nhân:** Thư mục assets thiếu file

**Giải pháp:**
1. Kiểm tra thư mục `assets/` có đầy đủ hình
2. Kiểm tra quyền: 644 cho file, 755 cho thư mục

### Không nhận thông báo Telegram

**Nguyên nhân:** Bot chưa được start

**Giải pháp:**
1. Mở Telegram, tìm bot: @Shopcode_notify_bot
2. Gửi lệnh `/start`
3. Thử tạo đơn hàng test lại

---

## 📞 THÔNG TIN HỖ TRỢ

### Tài khoản mặc định:
- Username: `admin`
- Password: `admin123` (ĐỔI NGAY!)

### Thông tin đã cấu hình:
- VietQR: TPBank - 22523112009
- Telegram Bot: @Shopcode_notify_bot
- Admin Chat ID: 7803422532

---

## 🎯 SAU KHI DEPLOY THÀNH CÔNG

### Việc cần làm:

1. **Đổi mật khẩu admin** (quan trọng!)
2. **Xóa sản phẩm mẫu** và thêm sản phẩm thật
3. **Cập nhật thông tin shop** trong database
4. **Test đầy đủ các tính năng**
5. **Backup database định kỳ**
6. **Theo dõi log lỗi**

### Tối ưu hóa:

- Bật OPcache trong PHP
- Sử dụng CDN cho assets
- Minify CSS/JS
- Tối ưu hóa hình ảnh
- Cài đặt cache

---

## 📚 TÀI LIỆU THAM KHẢO

- README.md - Tổng quan dự án
- HUONG_DAN_SU_DUNG.md - Hướng dẫn sử dụng
- CHANGELOG.md - Lịch sử phát triển

---

**Chúc bạn deploy thành công! 🎉**

Nếu gặp vấn đề, hãy kiểm tra lại từng bước theo hướng dẫn này.
