# VanhShop - Hệ thống Shop Online PHP

## Giới thiệu

VanhShop là một hệ thống thương mại điện tử (shop online) đầy đủ tính năng được xây dựng bằng PHP, tích hợp thanh toán tự động qua VietQR và thông báo qua Telegram Bot.

## Tính năng chính

### 1. Hệ thống người dùng
- ✅ Đăng ký/Đăng nhập
- ✅ Quản lý hồ sơ cá nhân
- ✅ Đổi mật khẩu
- ✅ Phân quyền User/Admin
- ✅ Quản lý số dư tài khoản

### 2. Quản lý sản phẩm
- ✅ Hiển thị danh sách sản phẩm
- ✅ Phân loại sản phẩm (Miễn phí/Có phí)
- ✅ Chi tiết sản phẩm
- ✅ Tìm kiếm và lọc sản phẩm

### 3. Giỏ hàng và Thanh toán
- ✅ Thêm/Xóa/Cập nhật giỏ hàng
- ✅ Thanh toán bằng số dư tài khoản
- ✅ Thanh toán qua VietQR (tự động tạo mã QR)
- ✅ Xem lịch sử đơn hàng

### 4. Hệ thống nạp tiền
- ✅ Nạp tiền vào tài khoản
- ✅ Tạo mã QR thanh toán tự động
- ✅ Lịch sử giao dịch nạp tiền

### 5. Tích hợp Telegram Bot
- ✅ Thông báo đơn hàng mới cho người dùng
- ✅ Thông báo cho Admin khi có đơn hàng
- ✅ Thông báo thanh toán thành công
- ✅ Thông báo nạp tiền thành công

### 6. Admin Panel (Đang phát triển)
- Quản lý sản phẩm (CRUD)
- Quản lý đơn hàng
- Quản lý người dùng
- Xác nhận thanh toán thủ công

## Công nghệ sử dụng

- **Backend**: PHP 8.1+
- **Database**: MySQL 8.0
- **Frontend**: HTML5, CSS3, JavaScript
- **CSS Framework**: Custom CSS (từ file gốc)
- **Icons**: Font Awesome 6.5
- **Payment**: VietQR API
- **Notification**: Telegram Bot API

## Cấu trúc dự án

```
shop_online/
├── public/                 # Thư mục public (document root)
│   ├── index.php          # Entry point
│   ├── assets/            # Hình ảnh sản phẩm
│   ├── css/               # File CSS
│   ├── js/                # File JavaScript
│   └── uploads/           # File upload
├── app/                   # Logic ứng dụng
│   ├── Controllers/       # Controllers
│   ├── Models/           # Models (Database)
│   ├── Views/            # Views (Templates)
│   ├── Core/             # Core classes
│   └── Config/           # Configuration
├── includes/             # Header/Footer
├── .env                  # Environment variables
└── database_schema.sql   # Database schema
```

## Cài đặt

### 1. Yêu cầu hệ thống
- PHP 7.4 trở lên
- MySQL 5.7 trở lên
- Extension: php-mysql, php-mbstring, php-curl, php-gd

### 2. Cài đặt database

```bash
mysql -u root -p < database_schema.sql
```

### 3. Cấu hình môi trường

Chỉnh sửa file `.env`:

```env
# Database Configuration
DB_HOST=localhost
DB_NAME=shop_online
DB_USER=root
DB_PASS=

# VietQR Configuration
VIETQR_BANK_ID=970422
VIETQR_ACCOUNT_NO=0123456789
VIETQR_ACCOUNT_NAME=NGUYEN VAN A

# Telegram Bot Configuration
TELEGRAM_BOT_TOKEN=your_bot_token_here
TELEGRAM_ADMIN_CHAT_ID=your_admin_chat_id_here
```

### 4. Khởi động server

```bash
cd public
php -S localhost:8000 index.php
```

Truy cập: http://localhost:8000

## Tài khoản mặc định

- **Username**: admin
- **Password**: admin123
- **Role**: Administrator

## Hướng dẫn cấu hình

### 1. Cấu hình VietQR

1. Đăng ký tài khoản ngân hàng hỗ trợ VietQR
2. Lấy thông tin:
   - Bank ID (Mã ngân hàng)
   - Số tài khoản
   - Tên chủ tài khoản
3. Cập nhật vào file `.env`

### 2. Cấu hình Telegram Bot

1. Tạo bot qua [@BotFather](https://t.me/BotFather)
2. Lấy Bot Token
3. Lấy Chat ID của bạn qua [@userinfobot](https://t.me/userinfobot)
4. Cập nhật vào file `.env`

**Để nhận thông báo:**
- Người dùng: Cập nhật Telegram Chat ID trong trang "Tài khoản"
- Admin: Cấu hình `TELEGRAM_ADMIN_CHAT_ID` trong `.env`

## Sử dụng

### Người dùng

1. **Đăng ký tài khoản**: Truy cập trang đăng ký
2. **Duyệt sản phẩm**: Xem danh sách sản phẩm miễn phí và có phí
3. **Thêm vào giỏ hàng**: Chọn sản phẩm và thêm vào giỏ
4. **Nạp tiền**: Nạp tiền vào tài khoản (nếu cần)
5. **Thanh toán**: Chọn phương thức thanh toán
   - Số dư: Thanh toán ngay lập tức
   - VietQR: Quét mã QR để thanh toán
6. **Tải sản phẩm**: Sau khi thanh toán thành công, tải sản phẩm trong mục "Đơn hàng"

### Admin

1. Đăng nhập với tài khoản admin
2. Truy cập Admin Panel (đang phát triển)
3. Quản lý sản phẩm, đơn hàng, người dùng

## API Endpoints

### VietQR
```
GET https://img.vietqr.io/image/{bank_id}-{account_no}-{template}.jpg?amount={amount}&addInfo={content}
```

### Telegram Bot
```
POST https://api.telegram.org/bot{token}/sendMessage
```

## Bảo mật

- ✅ Mã hóa mật khẩu với `password_hash()`
- ✅ Prepared statements để chống SQL Injection
- ✅ Session management
- ✅ CSRF protection (đang phát triển)
- ✅ XSS protection với `htmlspecialchars()`

## Tính năng sắp tới

- [ ] Admin Panel đầy đủ
- [ ] Xác thực email
- [ ] Webhook tự động xác nhận thanh toán
- [ ] Hệ thống đánh giá sản phẩm
- [ ] Mã giảm giá
- [ ] Báo cáo thống kê
- [ ] Export đơn hàng

## Lưu ý

1. **Thanh toán tự động**: Hiện tại hệ thống chưa tích hợp webhook từ ngân hàng. Admin cần xác nhận thanh toán thủ công hoặc tích hợp với payment gateway (VNPay, PayOS, etc.)

2. **Telegram Bot**: Cần cấu hình đúng Bot Token và Chat ID để nhận thông báo

3. **Production**: Trước khi deploy lên production:
   - Đổi mật khẩu admin
   - Cấu hình HTTPS
   - Bật error logging
   - Tắt display_errors
   - Cấu hình firewall

## Hỗ trợ

Nếu gặp vấn đề, vui lòng:
1. Kiểm tra log: `/tmp/php_server.log`
2. Kiểm tra database connection
3. Kiểm tra file permissions

## License

MIT License - Tự do sử dụng cho mục đích cá nhân và thương mại.

## Credits

- CSS Design: Từ project gốc vanhkazen-web_shop
- VietQR API: https://vietqr.io
- Font Awesome: https://fontawesome.com
- Telegram Bot API: https://core.telegram.org/bots/api

---

**Developed with ❤️ by Manus AI**
