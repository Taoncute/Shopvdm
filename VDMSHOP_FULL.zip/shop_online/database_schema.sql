-- Create database
CREATE DATABASE IF NOT EXISTS shop_online CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE shop_online;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    balance DECIMAL(15,2) DEFAULT 0.00,
    role ENUM('user', 'admin') DEFAULT 'user',
    telegram_chat_id VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Categories table
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(15,2) NOT NULL,
    image VARCHAR(255),
    stock INT DEFAULT 0,
    is_free BOOLEAN DEFAULT FALSE,
    download_url TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
    INDEX idx_category (category_id),
    INDEX idx_status (status),
    INDEX idx_price (price)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    order_code VARCHAR(50) UNIQUE NOT NULL,
    total_amount DECIMAL(15,2) NOT NULL,
    payment_method ENUM('balance', 'vietqr') DEFAULT 'vietqr',
    payment_status ENUM('pending', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
    payment_content VARCHAR(100),
    qr_code_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_order_code (order_code),
    INDEX idx_payment_status (payment_status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    product_price DECIMAL(15,2) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    subtotal DECIMAL(15,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    INDEX idx_order (order_id),
    INDEX idx_product (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Topup transactions table
CREATE TABLE IF NOT EXISTS topup_transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    transaction_code VARCHAR(50) UNIQUE NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    payment_status ENUM('pending', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
    payment_content VARCHAR(100),
    qr_code_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_transaction_code (transaction_code),
    INDEX idx_payment_status (payment_status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cart table
CREATE TABLE IF NOT EXISTS cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_product (user_id, product_id),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sessions table (optional, for database session storage)
CREATE TABLE IF NOT EXISTS sessions (
    id VARCHAR(128) PRIMARY KEY,
    user_id INT,
    data TEXT,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_last_activity (last_activity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default admin user (password: admin123)
INSERT INTO users (username, email, password, full_name, role, balance) 
VALUES ('admin', 'admin@vanhshop.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator', 'admin', 0.00)
ON DUPLICATE KEY UPDATE username=username;

-- Insert default categories
INSERT INTO categories (name, description) VALUES 
('Code Tình Yêu', 'Các mã nguồn về tình yêu, tỏ tình'),
('Code Sinh Nhật', 'Các mã nguồn chúc mừng sinh nhật'),
('Portfolio', 'Các mẫu portfolio, CV cá nhân'),
('Tiện Ích', 'Các công cụ tiện ích')
ON DUPLICATE KEY UPDATE name=name;

-- Insert sample products
INSERT INTO products (category_id, name, description, price, image, stock, is_free, download_url, status) VALUES 
(1, 'Hoa Tulips', 'Hiệu ứng hoa tulips đẹp mắt', 10000.00, 'buy2.jpg', 999, FALSE, NULL, 'active'),
(2, 'Matrix Birthday V2', 'Chúc mừng sinh nhật phong cách Matrix', 45000.00, 'buy1.jpg', 999, FALSE, NULL, 'active'),
(1, 'Thư Tình', 'Mẫu thư tình lãng mạn', 40000.00, 'buy3.jpg', 999, FALSE, NULL, 'active'),
(1, 'Thể hiện tình cảm', 'Code thể hiện tình cảm đặc biệt', 10000.00, 'buy4.jpg', 999, FALSE, NULL, 'active'),
(4, 'Troll Bạn Bè', 'Code troll bạn bè vui nhộn', 25000.00, 'troll.jpg', 999, FALSE, NULL, 'active'),
(2, 'Happy Birthday', 'Chúc mừng sinh nhật đơn giản', 25000.00, 'buy5.jpg', 999, FALSE, NULL, 'active'),
(3, 'Portfolio', 'Mẫu portfolio chuyên nghiệp', 0.00, 'portfolio2.jpg', 999, TRUE, 'https://www.mediafire.com/file/2ndusv8hoqw3unv/portfolio.zip/file', 'active'),
(3, 'Portfolio Dev Cá Nhân', 'Portfolio dành cho developer', 0.00, 'portfolio1.jpg', 999, TRUE, 'https://www.mediafire.com/file/873t1wavfqv7ccr/danhthiep.zip/file', 'active'),
(4, 'Vẽ Cờ Việt Nam - Python', 'Code vẽ cờ Việt Nam bằng Python', 0.00, 'vietnam_flag.jpg', 999, TRUE, 'https://www.mediafire.com/file/k4b051gxyunztw7/vietnam_flag.zip/file', 'active'),
(4, 'Random Password', 'Công cụ tạo mật khẩu ngẫu nhiên', 0.00, 'password.jpg', 999, TRUE, 'https://www.mediafire.com/file/dmtvbccs7xg6tm0/password.zip/file', 'active'),
(1, 'Tỏ Tình', 'Code tỏ tình đơn giản', 0.00, 'totinh.jpg', 999, TRUE, 'https://www.mediafire.com/file/6btbgrh80mwirqu/totinh.zip/file', 'active'),
(1, 'Đếm Ngày Yêu', 'Đếm số ngày yêu nhau', 0.00, 'free1.jpg', 999, TRUE, 'https://www.mediafire.com/file/ikqreafqinsquj6/LoveCounter.zip/file', 'active'),
(3, 'Profile Vid Bg', 'Profile với video background', 0.00, 'profile-loli.jpg', 999, TRUE, 'https://www.mediafire.com/file/e719rku5skslfsa/ttcn1.zip/file', 'active'),
(3, 'Portfolio Basic', 'Portfolio cơ bản cho mọi người', 0.00, 'portfolio3.jpg', 999, TRUE, 'https://www.mediafire.com/file/dodo2urvoqpoff6/ttcn2.zip/file', 'active')
ON DUPLICATE KEY UPDATE name=name;
