# HƯỚNG DẪN DEPLOY LÊN TINO GROUP HOSTING

## 📋 THÔNG TIN CỦA BẠN

- ✅ Domain: **vdmshop.io.vn** (đã có, đang hoạt động)
- ⏳ Hosting: Cần mua gói hosting tại Tino Group

---

## BƯỚC 1: MUA HOSTING TẠI TINO GROUP

### Cách mua:

1. Truy cập: https://tino.vn hoặc https://tino.org
2. Chọn **Hosting** → **Hosting Linux**
3. Chọn gói phù hợp:
   - **Gói Basic** (~50,000đ/tháng): Phù hợp bắt đầu
   - **Gói Standard** (~100,000đ/tháng): Khuyến nghị
   - **Gói Advanced**: Nếu cần hiệu năng cao

4. Yêu cầu:
   - PHP: 7.4 trở lên ✅
   - MySQL: 5.7 trở lên ✅
   - Dung lượng: Tối thiểu 1GB ✅

5. Thanh toán và nhận thông tin:
   - Username cPanel
   - Password cPanel
   - Link cPanel: https://tino.vn:2083

---

## BƯỚC 2: ĐĂNG NHẬP CPANEL

1. Truy cập: **https://tino.vn:2083** hoặc link trong email
2. Nhập:
   - Username: (từ email Tino gửi)
   - Password: (từ email Tino gửi)
3. Click **Log in**

---

## BƯỚC 3: UPLOAD FILE ZIP

### Trong cPanel:

1. Tìm và click **File Manager** (Quản lý File)
2. Vào thư mục **public_html**
3. Click nút **Upload** ở thanh menu trên
4. Click **Select File** → Chọn file **vanhshop_configured.zip**
5. Đợi upload hoàn tất (thanh xanh 100%)
6. Click **Go Back to...** để quay lại File Manager

### Giải nén file:

1. Trong **public_html**, tìm file **vanhshop_configured.zip**
2. Click chuột phải vào file → Chọn **Extract**
3. Đường dẫn giải nén: `/public_html/` → Click **Extract File(s)**
4. Đợi giải nén xong
5. Vào thư mục **shop_online** vừa giải nén
6. Vào thư mục **public**
7. **Chọn tất cả file** trong thư mục public (Ctrl+A)
8. Click **Move** → Nhập đường dẫn: `/public_html/`
9. Click **Move File(s)**
10. Xóa thư mục **shop_online** rỗng

**Kết quả:** Tất cả file website giờ nằm trong `public_html/`

---

## BƯỚC 4: TẠO DATABASE

### Trong cPanel:

1. Tìm mục **Databases** → Click **MySQL® Databases**

### Tạo Database:

2. Ở mục **Create New Database**:
   - Database Name: nhập `shop_online`
   - Click **Create Database**
   - Ghi lại tên đầy đủ: `username_shop_online` (ví dụ: `tinouser_shop_online`)

### Tạo User:

3. Ở mục **Add New User**:
   - Username: nhập `shop_user`
   - Password: Click **Password Generator** → Copy mật khẩu → **Use Password**
   - **GHI LẠI MẬT KHẨU NÀY!**
   - Click **Create User**
   - Ghi lại username đầy đủ: `username_shop_user` (ví dụ: `tinouser_shop_user`)

### Gán quyền:

4. Ở mục **Add User To Database**:
   - User: Chọn user vừa tạo (`username_shop_user`)
   - Database: Chọn database vừa tạo (`username_shop_online`)
   - Click **Add**
   
5. Trang mới hiện ra:
   - Tick chọn **ALL PRIVILEGES** (tất cả quyền)
   - Click **Make Changes**

**GHI LẠI THÔNG TIN:**
```
DB_HOST=localhost
DB_NAME=tinouser_shop_online (thay bằng tên của bạn)
DB_USER=tinouser_shop_user (thay bằng tên của bạn)
DB_PASS=mật_khẩu_vừa_tạo
```

---

## BƯỚC 5: IMPORT DATABASE

### Trong cPanel:

1. Tìm mục **Databases** → Click **phpMyAdmin**
2. Sidebar bên trái: Click vào database **username_shop_online**
3. Click tab **Import** (Nhập)
4. Click **Choose File** (Chọn file)
5. Tìm và chọn file **database_schema.sql** trong thư mục website
   - Đường dẫn: `/public_html/database_schema.sql`
6. Kéo xuống dưới → Click **Go** (Thực hiện)
7. Đợi import xong → Thấy thông báo màu xanh "Import has been successfully finished"

**Kiểm tra:**
- Sidebar trái sẽ hiển thị 8 tables: users, products, categories, orders, order_items, cart, topup_transactions, sessions

---

## BƯỚC 6: CẤU HÌNH FILE .ENV

### Trong File Manager:

1. Quay lại **File Manager** trong cPanel
2. Vào thư mục **public_html**
3. Tìm file **.env** (nếu không thấy, click **Settings** góc phải → Tick **Show Hidden Files**)
4. Click chuột phải vào file **.env** → Chọn **Edit**
5. Click **Edit** trong popup xác nhận

### Cập nhật thông tin:

Tìm và sửa các dòng sau:

```env
# Database Configuration
DB_HOST=localhost
DB_NAME=tinouser_shop_online    ← Thay bằng tên database của bạn
DB_USER=tinouser_shop_user      ← Thay bằng username của bạn
DB_PASS=mật_khẩu_database       ← Thay bằng mật khẩu đã ghi lại

# App Configuration
APP_NAME=VanhShop
APP_URL=https://vdmshop.io.vn   ← Domain của bạn
APP_ENV=production

# VietQR Configuration (ĐÃ CÓ - KHÔNG CẦN SỬA)
VIETQR_BANK_ID=970423
VIETQR_ACCOUNT_NO=22523112009
VIETQR_ACCOUNT_NAME=DUONG VINH MANH

# Telegram Bot Configuration (ĐÃ CÓ - KHÔNG CẦN SỬA)
TELEGRAM_BOT_TOKEN=8435659667:AAGK1zWRbkc1Y-XG6uaFz0nu1wW9k9WNH0Q
TELEGRAM_ADMIN_CHAT_ID=7803422532
```

6. Click **Save Changes** (góc phải trên)
7. Click **Close**

---

## BƯỚC 7: CẤP QUYỀN THƯ MỤC UPLOADS

### Trong File Manager:

1. Tìm thư mục **uploads** trong `public_html/`
2. Click chuột phải → Chọn **Change Permissions**
3. Tick các ô để có quyền: **755** hoặc **777**
   - Owner: Read, Write, Execute
   - Group: Read, Execute
   - World: Read, Execute
4. Click **Change Permissions**

---

## BƯỚC 8: TẠO FILE .HTACCESS

### Trong File Manager:

1. Trong thư mục **public_html**
2. Tìm file **.htaccess** (đã có sẵn từ file zip)
3. Nếu chưa có, click **+ File** → Tên: `.htaccess`
4. Click chuột phải → **Edit**
5. Dán nội dung sau:

```apache
RewriteEngine On

# Redirect to HTTPS
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# Protect .env
<Files .env>
    Order allow,deny
    Deny from all
</Files>

# PHP Settings
php_value upload_max_filesize 20M
php_value post_max_size 20M
php_value max_execution_time 300

# Disable directory browsing
Options -Indexes
```

6. Click **Save Changes**

---

## BƯỚC 9: CÀI ĐẶT SSL (HTTPS)

### Trong cPanel:

1. Tìm mục **Security** → Click **SSL/TLS Status**
2. Tìm domain **vdmshop.io.vn** trong danh sách
3. Click **Run AutoSSL** (nếu có)
   - Hoặc Tino có thể tự động cài SSL miễn phí

**Nếu không có AutoSSL:**
1. Vào **SSL/TLS** → **Manage SSL sites**
2. Liên hệ support Tino để cài Let's Encrypt miễn phí

**Đợi 5-10 phút để SSL active**

---

## BƯỚC 10: KIỂM TRA WEBSITE

### Truy cập website:

1. Mở trình duyệt
2. Truy cập: **https://vdmshop.io.vn**

### Checklist kiểm tra:

- [ ] Website hiển thị (không lỗi 404 hay 500)
- [ ] CSS hiển thị đúng (màu xanh sidebar)
- [ ] Hình ảnh sản phẩm hiển thị
- [ ] Đăng nhập admin:
  - Username: `admin`
  - Password: `admin123`
- [ ] Xem danh sách sản phẩm (14 sản phẩm)
- [ ] Thử đăng ký tài khoản mới
- [ ] Thử thêm sản phẩm vào giỏ hàng
- [ ] Tạo đơn hàng test
- [ ] Kiểm tra mã QR VietQR hiển thị đúng
- [ ] Kiểm tra nhận thông báo Telegram

---

## BƯỚC 11: BẢO MẬT (QUAN TRỌNG!)

### Đổi mật khẩu Admin:

1. Đăng nhập website
2. Username: `admin`, Password: `admin123`
3. Vào trang **Tài khoản**
4. Đổi mật khẩu ngay lập tức!

### Xóa file không cần thiết:

Trong File Manager, xóa các file:
- `database_schema.sql` (đã import rồi)
- `README.md`
- `HUONG_DAN_*.md`
- `CHANGELOG.md`
- File zip gốc

---

## XỬ LÝ LỖI THƯỜNG GẶP

### Lỗi 500 Internal Server Error

**Nguyên nhân:** File .htaccess hoặc quyền file

**Giải pháp:**
1. Đổi tên .htaccess thành .htaccess_backup
2. Tạo .htaccess mới với nội dung đơn giản hơn
3. Kiểm tra PHP version trong cPanel (cần 7.4+)

### Lỗi kết nối Database

**Nguyên nhân:** Thông tin .env sai

**Giải pháp:**
1. Kiểm tra lại file .env
2. Đảm bảo DB_NAME có prefix username (vd: `tinouser_shop_online`)
3. Kiểm tra DB_USER có prefix username
4. Kiểm tra DB_PASS đúng

### CSS không hiển thị

**Nguyên nhân:** Đường dẫn file

**Giải pháp:**
1. Kiểm tra thư mục `css/` có file `styles.css`
2. Clear cache: Ctrl + F5
3. Kiểm tra quyền file: 644

### Không nhận thông báo Telegram

**Giải pháp:**
1. Mở Telegram → Tìm @Shopcode_notify_bot
2. Gửi `/start`
3. Thử tạo đơn hàng test

---

## HỖ TRỢ TỪ TINO GROUP

Nếu gặp khó khăn:

**Hotline:** 1900 6680  
**Email:** support@tino.org  
**Live Chat:** https://tino.vn (góc phải dưới)

---

## SAU KHI HOÀN THÀNH

### Website của bạn:
- URL: https://vdmshop.io.vn
- Admin: https://vdmshop.io.vn/login.php

### Việc cần làm tiếp:
1. ✅ Đổi mật khẩu admin
2. ✅ Xóa sản phẩm mẫu
3. ✅ Thêm sản phẩm thật của bạn
4. ✅ Test đầy đủ tính năng
5. ✅ Backup database định kỳ

---

**CHÚC BẠN THÀNH CÔNG! 🎉**

Website vĩnh viễn của bạn đã sẵn sàng tại: **https://vdmshop.io.vn**
