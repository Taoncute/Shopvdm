<?php
// Load environment variables
function loadEnv($path) {
    if (!file_exists($path)) {
        return;
    }
    
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) {
            continue;
        }
        
        list($name, $value) = explode('=', $line, 2);
        $name = trim($name);
        $value = trim($value);
        
        if (!array_key_exists($name, $_ENV)) {
            $_ENV[$name] = $value;
            putenv("$name=$value");
        }
    }
}

loadEnv(__DIR__ . '/../../.env');

// Database configuration
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'shop_online');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');

// App configuration
define('APP_NAME', getenv('APP_NAME') ?: 'VanhShop');
define('APP_URL', getenv('APP_URL') ?: 'http://localhost:8000');
define('APP_ENV', getenv('APP_ENV') ?: 'development');

// VietQR configuration
define('VIETQR_BANK_ID', getenv('VIETQR_BANK_ID') ?: '970422');
define('VIETQR_ACCOUNT_NO', getenv('VIETQR_ACCOUNT_NO') ?: '');
define('VIETQR_ACCOUNT_NAME', getenv('VIETQR_ACCOUNT_NAME') ?: '');
define('VIETQR_TEMPLATE', getenv('VIETQR_TEMPLATE') ?: 'compact');

// Telegram Bot configuration
define('TELEGRAM_BOT_TOKEN', getenv('TELEGRAM_BOT_TOKEN') ?: '');
define('TELEGRAM_ADMIN_CHAT_ID', getenv('TELEGRAM_ADMIN_CHAT_ID') ?: '');

// Security configuration
define('SESSION_LIFETIME', getenv('SESSION_LIFETIME') ?: 7200);
define('CSRF_TOKEN_NAME', getenv('CSRF_TOKEN_NAME') ?: 'csrf_token');

// Path configuration
define('ROOT_PATH', dirname(dirname(__DIR__)));
define('APP_PATH', ROOT_PATH . '/app');
define('PUBLIC_PATH', ROOT_PATH . '/public');
define('UPLOAD_PATH', PUBLIC_PATH . '/uploads');

// URL configuration
define('BASE_URL', APP_URL);
define('ASSETS_URL', BASE_URL . '/assets');
define('CSS_URL', BASE_URL . '/css');
define('JS_URL', BASE_URL . '/js');
