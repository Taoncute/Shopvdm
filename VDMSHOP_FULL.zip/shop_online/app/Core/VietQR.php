<?php
class VietQR {
    /**
     * Generate VietQR payment URL
     * 
     * @param string $accountNo Bank account number
     * @param string $accountName Account holder name
     * @param int $amount Payment amount
     * @param string $content Payment content/description
     * @param string $bankId Bank ID (default: 970422 - MB Bank)
     * @param string $template QR template (compact, compact2, qr_only, print)
     * @return string QR code image URL
     */
    public static function generateQRUrl($accountNo, $accountName, $amount, $content, $bankId = null, $template = null) {
        $bankId = $bankId ?? VIETQR_BANK_ID;
        $template = $template ?? VIETQR_TEMPLATE;
        
        // VietQR API URL
        $baseUrl = "https://img.vietqr.io/image";
        
        // Build URL
        $url = sprintf(
            "%s/%s-%s-%s.jpg?amount=%d&addInfo=%s&accountName=%s",
            $baseUrl,
            $bankId,
            $accountNo,
            $template,
            $amount,
            urlencode($content),
            urlencode($accountName)
        );
        
        return $url;
    }
    
    /**
     * Generate QR code for order payment
     */
    public static function generateOrderQR($orderCode, $amount) {
        return self::generateQRUrl(
            VIETQR_ACCOUNT_NO,
            VIETQR_ACCOUNT_NAME,
            $amount,
            $orderCode,
            VIETQR_BANK_ID,
            VIETQR_TEMPLATE
        );
    }
    
    /**
     * Generate QR code for topup transaction
     */
    public static function generateTopupQR($transactionCode, $amount) {
        return self::generateQRUrl(
            VIETQR_ACCOUNT_NO,
            VIETQR_ACCOUNT_NAME,
            $amount,
            $transactionCode,
            VIETQR_BANK_ID,
            VIETQR_TEMPLATE
        );
    }
    
    /**
     * Verify payment (This is a placeholder - you need to integrate with bank API)
     * In production, you should use webhook from payment gateway or bank API
     */
    public static function verifyPayment($transactionCode, $amount) {
        // TODO: Implement actual payment verification with bank API
        // This is just a placeholder
        // You can use services like:
        // - VietQR API (if they provide verification)
        // - Bank's API (if available)
        // - Third-party payment gateway (PayOS, VNPay, etc.)
        
        return false;
    }
}
