<?php
class TelegramBot {
    private $botToken;
    private $apiUrl;
    
    public function __construct() {
        $this->botToken = TELEGRAM_BOT_TOKEN;
        $this->apiUrl = "https://api.telegram.org/bot{$this->botToken}/";
    }
    
    /**
     * Send message to a chat
     */
    public function sendMessage($chatId, $text, $parseMode = 'HTML') {
        if (empty($this->botToken) || empty($chatId)) {
            return false;
        }
        
        $data = [
            'chat_id' => $chatId,
            'text' => $text,
            'parse_mode' => $parseMode
        ];
        
        return $this->makeRequest('sendMessage', $data);
    }
    
    /**
     * Send message to admin
     */
    public function sendToAdmin($text, $parseMode = 'HTML') {
        $adminChatId = TELEGRAM_ADMIN_CHAT_ID;
        return $this->sendMessage($adminChatId, $text, $parseMode);
    }
    
    /**
     * Notify user about new order
     */
    public function notifyNewOrder($userChatId, $orderCode, $totalAmount, $items) {
        $itemsList = '';
        foreach ($items as $item) {
            $itemsList .= "• {$item['product_name']} x{$item['quantity']} - " . number_format($item['subtotal'], 0, ',', '.') . "đ\n";
        }
        
        $message = "🛒 <b>Đơn hàng mới</b>\n\n";
        $message .= "📋 Mã đơn: <code>{$orderCode}</code>\n";
        $message .= "💰 Tổng tiền: <b>" . number_format($totalAmount, 0, ',', '.') . "đ</b>\n\n";
        $message .= "📦 Sản phẩm:\n{$itemsList}\n";
        $message .= "⏰ Thời gian: " . date('d/m/Y H:i:s') . "\n\n";
        $message .= "Vui lòng thanh toán để hoàn tất đơn hàng.";
        
        return $this->sendMessage($userChatId, $message);
    }
    
    /**
     * Notify admin about new order
     */
    public function notifyAdminNewOrder($username, $orderCode, $totalAmount, $items) {
        $itemsList = '';
        foreach ($items as $item) {
            $itemsList .= "• {$item['product_name']} x{$item['quantity']}\n";
        }
        
        $message = "🔔 <b>ĐƠN HÀNG MỚI</b>\n\n";
        $message .= "👤 Khách hàng: <b>{$username}</b>\n";
        $message .= "📋 Mã đơn: <code>{$orderCode}</code>\n";
        $message .= "💰 Tổng tiền: <b>" . number_format($totalAmount, 0, ',', '.') . "đ</b>\n\n";
        $message .= "📦 Sản phẩm:\n{$itemsList}\n";
        $message .= "⏰ " . date('d/m/Y H:i:s');
        
        return $this->sendToAdmin($message);
    }
    
    /**
     * Notify user about payment confirmation
     */
    public function notifyPaymentSuccess($userChatId, $orderCode, $totalAmount) {
        $message = "✅ <b>Thanh toán thành công!</b>\n\n";
        $message .= "📋 Mã đơn: <code>{$orderCode}</code>\n";
        $message .= "💰 Số tiền: <b>" . number_format($totalAmount, 0, ',', '.') . "đ</b>\n\n";
        $message .= "Cảm ơn bạn đã mua hàng! 🎉\n";
        $message .= "Bạn có thể xem chi tiết đơn hàng trong mục 'Đơn hàng' trên website.";
        
        return $this->sendMessage($userChatId, $message);
    }
    
    /**
     * Notify admin about payment confirmation
     */
    public function notifyAdminPaymentSuccess($username, $orderCode, $totalAmount) {
        $message = "💰 <b>THANH TOÁN THÀNH CÔNG</b>\n\n";
        $message .= "👤 Khách hàng: <b>{$username}</b>\n";
        $message .= "📋 Mã đơn: <code>{$orderCode}</code>\n";
        $message .= "💵 Số tiền: <b>" . number_format($totalAmount, 0, ',', '.') . "đ</b>\n";
        $message .= "⏰ " . date('d/m/Y H:i:s');
        
        return $this->sendToAdmin($message);
    }
    
    /**
     * Notify user about topup success
     */
    public function notifyTopupSuccess($userChatId, $transactionCode, $amount, $newBalance) {
        $message = "💳 <b>Nạp tiền thành công!</b>\n\n";
        $message .= "📋 Mã giao dịch: <code>{$transactionCode}</code>\n";
        $message .= "💰 Số tiền nạp: <b>" . number_format($amount, 0, ',', '.') . "đ</b>\n";
        $message .= "💵 Số dư mới: <b>" . number_format($newBalance, 0, ',', '.') . "đ</b>\n\n";
        $message .= "⏰ " . date('d/m/Y H:i:s');
        
        return $this->sendMessage($userChatId, $message);
    }
    
    /**
     * Notify admin about topup
     */
    public function notifyAdminTopup($username, $transactionCode, $amount) {
        $message = "💳 <b>NẠP TIỀN MỚI</b>\n\n";
        $message .= "👤 Khách hàng: <b>{$username}</b>\n";
        $message .= "📋 Mã GD: <code>{$transactionCode}</code>\n";
        $message .= "💰 Số tiền: <b>" . number_format($amount, 0, ',', '.') . "đ</b>\n";
        $message .= "⏰ " . date('d/m/Y H:i:s');
        
        return $this->sendToAdmin($message);
    }
    
    /**
     * Make API request to Telegram
     */
    private function makeRequest($method, $data) {
        try {
            $url = $this->apiUrl . $method;
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            
            $result = curl_exec($ch);
            curl_close($ch);
            
            return json_decode($result, true);
        } catch (Exception $e) {
            return false;
        }
    }
}
