<?php
$pageTitle = 'Giỏ hàng';
require_once __DIR__ . '/../../../includes/header.php';
?>

<style>
    .cart-container {
        max-width: 1000px;
        margin: 30px auto;
    }
    .cart-table {
        width: 100%;
        background: white;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    .cart-table table {
        width: 100%;
        border-collapse: collapse;
    }
    .cart-table th {
        background: #007bff;
        color: white;
        padding: 15px;
        text-align: left;
    }
    .cart-table td {
        padding: 15px;
        border-bottom: 1px solid #eee;
    }
    .cart-table tr:last-child td {
        border-bottom: none;
    }
    .product-img {
        width: 80px;
        height: 80px;
        object-fit: cover;
        border-radius: 8px;
    }
    .quantity-input {
        width: 60px;
        padding: 5px;
        text-align: center;
        border: 1px solid #ddd;
        border-radius: 4px;
    }
    .btn-remove {
        background: #dc3545;
        color: white;
        border: none;
        padding: 8px 15px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 14px;
    }
    .btn-remove:hover {
        background: #c82333;
    }
    .cart-summary {
        background: white;
        padding: 20px;
        border-radius: 12px;
        margin-top: 20px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    .cart-summary h3 {
        color: #007bff;
        margin-bottom: 15px;
    }
    .total-row {
        display: flex;
        justify-content: space-between;
        font-size: 20px;
        font-weight: bold;
        color: #007bff;
        margin: 15px 0;
        padding-top: 15px;
        border-top: 2px solid #007bff;
    }
    .btn-checkout {
        width: 100%;
        padding: 15px;
        background: #28a745;
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 18px;
        font-weight: bold;
        cursor: pointer;
        transition: background 0.3s ease;
    }
    .btn-checkout:hover {
        background: #218838;
    }
    .empty-cart {
        text-align: center;
        padding: 60px 20px;
        background: white;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    .empty-cart i {
        font-size: 64px;
        color: #ccc;
        margin-bottom: 20px;
    }
</style>

<div class="cart-container">
    <h1><i class="fa-solid fa-shopping-cart"></i> Giỏ hàng của bạn</h1>
    
    <?php if (empty($items)): ?>
        <div class="empty-cart">
            <i class="fa-solid fa-shopping-cart"></i>
            <h2>Giỏ hàng trống</h2>
            <p>Bạn chưa có sản phẩm nào trong giỏ hàng</p>
            <a href="/products.php" class="btn-checkout" style="display: inline-block; width: auto; padding: 12px 30px; margin-top: 20px;">
                <i class="fa-solid fa-shopping-bag"></i> Tiếp tục mua sắm
            </a>
        </div>
    <?php else: ?>
        <div class="cart-table">
            <table>
                <thead>
                    <tr>
                        <th>Sản phẩm</th>
                        <th>Tên</th>
                        <th>Giá</th>
                        <th>Số lượng</th>
                        <th>Tổng</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                        <tr>
                            <td>
                                <img src="/assets/<?php echo htmlspecialchars($item['image']); ?>" 
                                     alt="<?php echo htmlspecialchars($item['name']); ?>" 
                                     class="product-img">
                            </td>
                            <td><?php echo htmlspecialchars($item['name']); ?></td>
                            <td><?php echo number_format($item['price'], 0, ',', '.'); ?>đ</td>
                            <td>
                                <form action="/cart.php?action=update" method="POST" style="display: inline;">
                                    <input type="hidden" name="product_id" value="<?php echo $item['product_id']; ?>">
                                    <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" 
                                           min="1" max="<?php echo $item['stock']; ?>" class="quantity-input"
                                           onchange="this.form.submit()">
                                </form>
                            </td>
                            <td><strong><?php echo number_format($item['price'] * $item['quantity'], 0, ',', '.'); ?>đ</strong></td>
                            <td>
                                <a href="/cart.php?action=remove&product_id=<?php echo $item['product_id']; ?>" 
                                   class="btn-remove"
                                   onclick="return confirm('Bạn có chắc muốn xóa sản phẩm này?')">
                                    <i class="fa-solid fa-trash"></i> Xóa
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <div class="cart-summary">
            <h3><i class="fa-solid fa-receipt"></i> Tổng đơn hàng</h3>
            <div class="total-row">
                <span>Tổng cộng:</span>
                <span><?php echo number_format($total, 0, ',', '.'); ?>đ</span>
            </div>
            <a href="/checkout.php">
                <button class="btn-checkout">
                    <i class="fa-solid fa-credit-card"></i> Tiến hành thanh toán
                </button>
            </a>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../../includes/footer.php'; ?>
