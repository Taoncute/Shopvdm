<?php
$pageTitle = 'Thanh toán';
require_once __DIR__ . '/../../../includes/header.php';
?>

<style>
    .checkout-container {
        max-width: 900px;
        margin: 30px auto;
    }
    .checkout-card {
        background: white;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
    }
    .checkout-card h2 {
        color: #007bff;
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 2px solid #007bff;
    }
    .order-item {
        display: flex;
        align-items: center;
        padding: 15px;
        border-bottom: 1px solid #eee;
    }
    .order-item:last-child {
        border-bottom: none;
    }
    .order-item img {
        width: 60px;
        height: 60px;
        object-fit: cover;
        border-radius: 8px;
        margin-right: 15px;
    }
    .order-item-info {
        flex: 1;
    }
    .order-item-price {
        font-weight: bold;
        color: #007bff;
    }
    .payment-method {
        margin: 20px 0;
    }
    .payment-option {
        display: flex;
        align-items: center;
        padding: 15px;
        border: 2px solid #ddd;
        border-radius: 8px;
        margin-bottom: 10px;
        cursor: pointer;
        transition: all 0.3s ease;
    }
    .payment-option:hover {
        border-color: #007bff;
        background: #f8f9fa;
    }
    .payment-option input[type="radio"] {
        margin-right: 15px;
        width: 20px;
        height: 20px;
    }
    .payment-option.selected {
        border-color: #007bff;
        background: #e7f3ff;
    }
    .total-summary {
        background: #f8f9fa;
        padding: 20px;
        border-radius: 8px;
        margin: 20px 0;
    }
    .total-row {
        display: flex;
        justify-content: space-between;
        margin: 10px 0;
        font-size: 18px;
    }
    .total-row.final {
        font-size: 24px;
        font-weight: bold;
        color: #007bff;
        padding-top: 15px;
        border-top: 2px solid #007bff;
    }
    .btn-submit {
        width: 100%;
        padding: 15px;
        background: #28a745;
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 18px;
        font-weight: bold;
        cursor: pointer;
        transition: background 0.3s ease;
    }
    .btn-submit:hover {
        background: #218838;
    }
    .balance-info {
        background: #fff3cd;
        border: 1px solid #ffc107;
        padding: 15px;
        border-radius: 8px;
        margin: 15px 0;
    }
    .balance-info.insufficient {
        background: #f8d7da;
        border-color: #dc3545;
    }
</style>

<div class="checkout-container">
    <h1><i class="fa-solid fa-credit-card"></i> Thanh toán đơn hàng</h1>
    
    <div class="checkout-card">
        <h2><i class="fa-solid fa-box"></i> Chi tiết đơn hàng</h2>
        <?php foreach ($items as $item): ?>
            <div class="order-item">
                <img src="/assets/<?php echo htmlspecialchars($item['image']); ?>" 
                     alt="<?php echo htmlspecialchars($item['name']); ?>">
                <div class="order-item-info">
                    <strong><?php echo htmlspecialchars($item['name']); ?></strong>
                    <div>Số lượng: <?php echo $item['quantity']; ?></div>
                </div>
                <div class="order-item-price">
                    <?php echo number_format($item['price'] * $item['quantity'], 0, ',', '.'); ?>đ
                </div>
            </div>
        <?php endforeach; ?>
        
        <div class="total-summary">
            <div class="total-row final">
                <span>Tổng thanh toán:</span>
                <span><?php echo number_format($total, 0, ',', '.'); ?>đ</span>
            </div>
        </div>
    </div>
    
    <div class="checkout-card">
        <h2><i class="fa-solid fa-wallet"></i> Phương thức thanh toán</h2>
        
        <form action="/checkout.php" method="POST" id="checkoutForm">
            <div class="payment-method">
                <label class="payment-option" onclick="selectPayment('balance')">
                    <input type="radio" name="payment_method" value="balance" id="payment_balance">
                    <div>
                        <strong><i class="fa-solid fa-wallet"></i> Thanh toán bằng số dư tài khoản</strong>
                        <div style="margin-top: 5px; color: #666;">
                            Số dư hiện tại: <strong style="color: <?php echo $user['balance'] >= $total ? '#28a745' : '#dc3545'; ?>">
                                <?php echo number_format($user['balance'], 0, ',', '.'); ?>đ
                            </strong>
                        </div>
                    </div>
                </label>
                
                <?php if ($user['balance'] < $total): ?>
                    <div class="balance-info insufficient">
                        <i class="fa-solid fa-exclamation-triangle"></i>
                        Số dư không đủ. Vui lòng <a href="/topup.php" style="color: #007bff; font-weight: bold;">nạp thêm tiền</a> 
                        hoặc chọn phương thức thanh toán khác.
                    </div>
                <?php endif; ?>
                
                <label class="payment-option selected" onclick="selectPayment('vietqr')">
                    <input type="radio" name="payment_method" value="vietqr" id="payment_vietqr" checked>
                    <div>
                        <strong><i class="fa-solid fa-qrcode"></i> Thanh toán qua VietQR</strong>
                        <div style="margin-top: 5px; color: #666;">
                            Quét mã QR để thanh toán qua ngân hàng
                        </div>
                    </div>
                </label>
            </div>
            
            <button type="submit" class="btn-submit">
                <i class="fa-solid fa-check-circle"></i> Xác nhận thanh toán
            </button>
        </form>
    </div>
</div>

<script>
    function selectPayment(method) {
        document.querySelectorAll('.payment-option').forEach(el => {
            el.classList.remove('selected');
        });
        event.currentTarget.classList.add('selected');
        document.getElementById('payment_' + method).checked = true;
    }
</script>

<?php require_once __DIR__ . '/../../../includes/footer.php'; ?>
