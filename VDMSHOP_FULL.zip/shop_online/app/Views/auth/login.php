<?php
$pageTitle = 'Đăng nhập';
require_once __DIR__ . '/../../../includes/header.php';
?>

<style>
    .auth-container {
        max-width: 450px;
        margin: 50px auto;
        background: white;
        padding: 40px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    .auth-container h1 {
        text-align: center;
        color: #007bff;
        margin-bottom: 30px;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #333;
    }
    .form-group input {
        width: 100%;
        padding: 12px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-size: 14px;
        box-sizing: border-box;
    }
    .form-group input:focus {
        outline: none;
        border-color: #007bff;
    }
    .form-check {
        margin: 15px 0;
    }
    .form-check input {
        width: auto;
        margin-right: 8px;
    }
    .btn {
        width: 100%;
        padding: 12px;
        background: #007bff;
        color: white;
        border: none;
        border-radius: 6px;
        font-size: 16px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.3s ease;
    }
    .btn:hover {
        background: #0056b3;
    }
    .auth-footer {
        text-align: center;
        margin-top: 20px;
        color: #666;
    }
    .auth-footer a {
        color: #007bff;
        text-decoration: none;
    }
    .auth-footer a:hover {
        text-decoration: underline;
    }
</style>

<div class="auth-container">
    <h1><i class="fa-solid fa-sign-in-alt"></i> Đăng nhập</h1>
    
    <form action="/login.php" method="POST">
        <div class="form-group">
            <label for="username"><i class="fa-solid fa-user"></i> Tên đăng nhập hoặc Email</label>
            <input type="text" id="username" name="username" required>
        </div>
        
        <div class="form-group">
            <label for="password"><i class="fa-solid fa-lock"></i> Mật khẩu</label>
            <input type="password" id="password" name="password" required>
        </div>
        
        <div class="form-check">
            <label>
                <input type="checkbox" name="remember" value="1">
                Ghi nhớ đăng nhập
            </label>
        </div>
        
        <button type="submit" class="btn">Đăng nhập</button>
    </form>
    
    <div class="auth-footer">
        Chưa có tài khoản? <a href="/register.php">Đăng ký ngay</a>
    </div>
</div>

<?php require_once __DIR__ . '/../../../includes/footer.php'; ?>
