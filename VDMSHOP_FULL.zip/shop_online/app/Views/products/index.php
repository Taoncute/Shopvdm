<?php
$pageTitle = 'Sản phẩm';
require_once __DIR__ . '/../../../includes/header.php';
?>

<h1>
    <?php 
    if (isset($_GET['type']) && $_GET['type'] === 'free') {
        echo '<i class="fa-solid fa-gift"></i> Sản phẩm miễn phí';
    } elseif (isset($_GET['type']) && $_GET['type'] === 'paid') {
        echo '<i class="fa-solid fa-sack-dollar"></i> Sản phẩm có phí';
    } else {
        echo '<i class="fa-solid fa-layer-group"></i> Tất cả sản phẩm';
    }
    ?>
</h1>

<div class="container">
    <?php if (empty($products)): ?>
        <p style="text-align: center; width: 100%; padding: 40px; color: #666;">
            <i class="fa-solid fa-box-open" style="font-size: 48px; display: block; margin-bottom: 20px;"></i>
            Không có sản phẩm nào
        </p>
    <?php else: ?>
        <?php foreach ($products as $product): ?>
            <div class="code-item">
                <img src="/assets/<?php echo htmlspecialchars($product['image']); ?>" 
                     alt="<?php echo htmlspecialchars($product['name']); ?>">
                <p class="code-title"><?php echo htmlspecialchars($product['name']); ?></p>
                <p class="price">
                    <?php if ($product['is_free']): ?>
                        Miễn phí
                    <?php else: ?>
                        Giá: <?php echo number_format($product['price'], 0, ',', '.'); ?>đ
                    <?php endif; ?>
                </p>
                <div class="buttons">
                    <?php if ($product['is_free']): ?>
                        <?php if ($product['download_url']): ?>
                            <a href="<?php echo htmlspecialchars($product['download_url']); ?>" 
                               target="_blank">
                                <i class="fa-solid fa-download"></i> Tải xuống
                            </a>
                        <?php else: ?>
                            <a href="/product.php?id=<?php echo $product['id']; ?>">
                                <i class="fa-solid fa-eye"></i> Xem chi tiết
                            </a>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if (Session::isLoggedIn()): ?>
                            <a href="/cart.php?action=add&product_id=<?php echo $product['id']; ?>">
                                <i class="fa-solid fa-cart-plus"></i> Thêm vào giỏ
                            </a>
                        <?php else: ?>
                            <a href="/login.php">
                                <i class="fa-solid fa-sign-in-alt"></i> Đăng nhập để mua
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../../includes/footer.php'; ?>
