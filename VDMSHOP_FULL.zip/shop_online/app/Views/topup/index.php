<?php
$pageTitle = 'Nạp tiền';
require_once __DIR__ . '/../../../includes/header.php';
?>

<style>
    .topup-container {
        max-width: 800px;
        margin: 30px auto;
    }
    .topup-card {
        background: white;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
    }
    .topup-card h2 {
        color: #007bff;
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 2px solid #007bff;
    }
    .balance-display {
        background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
        color: white;
        padding: 30px;
        border-radius: 12px;
        text-align: center;
        margin-bottom: 30px;
    }
    .balance-display h3 {
        margin: 0 0 10px 0;
        font-size: 18px;
        opacity: 0.9;
    }
    .balance-display .amount {
        font-size: 48px;
        font-weight: bold;
        margin: 0;
    }
    .amount-options {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 15px;
        margin: 20px 0;
    }
    .amount-btn {
        padding: 20px;
        background: #f8f9fa;
        border: 2px solid #ddd;
        border-radius: 8px;
        cursor: pointer;
        text-align: center;
        font-weight: bold;
        transition: all 0.3s ease;
    }
    .amount-btn:hover {
        border-color: #007bff;
        background: #e7f3ff;
    }
    .amount-btn.selected {
        border-color: #007bff;
        background: #007bff;
        color: white;
    }
    .form-group {
        margin: 20px 0;
    }
    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #333;
    }
    .form-group input {
        width: 100%;
        padding: 12px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-size: 16px;
        box-sizing: border-box;
    }
    .btn-submit {
        width: 100%;
        padding: 15px;
        background: #28a745;
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 18px;
        font-weight: bold;
        cursor: pointer;
        transition: background 0.3s ease;
    }
    .btn-submit:hover {
        background: #218838;
    }
    .history-table {
        width: 100%;
        border-collapse: collapse;
    }
    .history-table th {
        background: #f8f9fa;
        padding: 12px;
        text-align: left;
        border-bottom: 2px solid #ddd;
    }
    .history-table td {
        padding: 12px;
        border-bottom: 1px solid #eee;
    }
    .status-badge {
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: bold;
    }
    .status-pending {
        background: #fff3cd;
        color: #856404;
    }
    .status-completed {
        background: #d4edda;
        color: #155724;
    }
    .status-failed {
        background: #f8d7da;
        color: #721c24;
    }
</style>

<div class="topup-container">
    <h1><i class="fa-solid fa-credit-card"></i> Nạp tiền vào tài khoản</h1>
    
    <div class="balance-display">
        <h3><i class="fa-solid fa-wallet"></i> Số dư hiện tại</h3>
        <p class="amount"><?php echo number_format($user['balance'], 0, ',', '.'); ?>đ</p>
    </div>
    
    <div class="topup-card">
        <h2><i class="fa-solid fa-money-bill-wave"></i> Chọn số tiền nạp</h2>
        
        <form action="/topup.php" method="POST" id="topupForm">
            <div class="amount-options">
                <div class="amount-btn" onclick="selectAmount(10000)">10,000đ</div>
                <div class="amount-btn" onclick="selectAmount(20000)">20,000đ</div>
                <div class="amount-btn" onclick="selectAmount(50000)">50,000đ</div>
                <div class="amount-btn" onclick="selectAmount(100000)">100,000đ</div>
                <div class="amount-btn" onclick="selectAmount(200000)">200,000đ</div>
                <div class="amount-btn" onclick="selectAmount(500000)">500,000đ</div>
            </div>
            
            <div class="form-group">
                <label for="amount"><i class="fa-solid fa-coins"></i> Hoặc nhập số tiền khác (VNĐ)</label>
                <input type="number" id="amount" name="amount" min="10000" max="50000000" 
                       placeholder="Nhập số tiền (tối thiểu 10,000đ)" required>
            </div>
            
            <button type="submit" class="btn-submit">
                <i class="fa-solid fa-qrcode"></i> Tạo mã QR thanh toán
            </button>
        </form>
    </div>
    
    <?php if (!empty($topups)): ?>
        <div class="topup-card">
            <h2><i class="fa-solid fa-history"></i> Lịch sử nạp tiền</h2>
            <table class="history-table">
                <thead>
                    <tr>
                        <th>Mã giao dịch</th>
                        <th>Số tiền</th>
                        <th>Trạng thái</th>
                        <th>Thời gian</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($topups as $topup): ?>
                        <tr>
                            <td><code><?php echo htmlspecialchars($topup['transaction_code']); ?></code></td>
                            <td><strong><?php echo number_format($topup['amount'], 0, ',', '.'); ?>đ</strong></td>
                            <td>
                                <?php
                                $statusClass = 'status-' . $topup['payment_status'];
                                $statusText = [
                                    'pending' => 'Chờ thanh toán',
                                    'completed' => 'Thành công',
                                    'failed' => 'Thất bại',
                                    'cancelled' => 'Đã hủy'
                                ];
                                ?>
                                <span class="status-badge <?php echo $statusClass; ?>">
                                    <?php echo $statusText[$topup['payment_status']] ?? $topup['payment_status']; ?>
                                </span>
                            </td>
                            <td><?php echo date('d/m/Y H:i', strtotime($topup['created_at'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<script>
    function selectAmount(amount) {
        document.querySelectorAll('.amount-btn').forEach(btn => {
            btn.classList.remove('selected');
        });
        event.currentTarget.classList.add('selected');
        document.getElementById('amount').value = amount;
    }
</script>

<?php require_once __DIR__ . '/../../../includes/footer.php'; ?>
