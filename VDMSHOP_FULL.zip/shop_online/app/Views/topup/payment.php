<?php
$pageTitle = 'Thanh toán nạp tiền';
require_once __DIR__ . '/../../../includes/header.php';
?>

<style>
    .payment-container {
        max-width: 700px;
        margin: 30px auto;
    }
    .payment-card {
        background: white;
        padding: 40px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        text-align: center;
    }
    .payment-card h2 {
        color: #007bff;
        margin-bottom: 20px;
    }
    .qr-code {
        max-width: 400px;
        width: 100%;
        margin: 20px auto;
        border: 3px solid #28a745;
        border-radius: 12px;
        padding: 10px;
        background: white;
    }
    .qr-code img {
        width: 100%;
        border-radius: 8px;
    }
    .payment-info {
        background: #f8f9fa;
        padding: 20px;
        border-radius: 8px;
        margin: 20px 0;
        text-align: left;
    }
    .payment-info p {
        margin: 10px 0;
        font-size: 16px;
    }
    .payment-info strong {
        color: #007bff;
    }
    .transaction-code {
        font-size: 24px;
        font-weight: bold;
        color: #28a745;
        padding: 15px;
        background: #d4edda;
        border-radius: 8px;
        margin: 20px 0;
    }
    .instructions {
        background: #e7f3ff;
        padding: 20px;
        border-radius: 8px;
        margin: 20px 0;
        text-align: left;
    }
    .instructions h3 {
        color: #007bff;
        margin-bottom: 15px;
    }
    .instructions ol {
        margin-left: 20px;
    }
    .instructions li {
        margin: 10px 0;
        line-height: 1.6;
    }
    .btn-check {
        padding: 15px 40px;
        background: #28a745;
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        margin: 10px;
        transition: background 0.3s ease;
    }
    .btn-check:hover {
        background: #218838;
    }
    .btn-back {
        padding: 15px 40px;
        background: #6c757d;
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        margin: 10px;
        transition: background 0.3s ease;
    }
    .btn-back:hover {
        background: #5a6268;
    }
</style>

<div class="payment-container">
    <div class="payment-card">
        <h1><i class="fa-solid fa-qrcode"></i> Quét mã QR để nạp tiền</h1>
        
        <div class="qr-code">
            <img src="<?php echo htmlspecialchars($topup['qr_code_url']); ?>" 
                 alt="QR Code nạp tiền">
        </div>
        
        <div class="transaction-code">
            Mã giao dịch: <?php echo htmlspecialchars($topup['transaction_code']); ?>
        </div>
        
        <div class="payment-info">
            <p><strong>Số tiền nạp:</strong> <?php echo number_format($topup['amount'], 0, ',', '.'); ?>đ</p>
            <p><strong>Ngân hàng:</strong> <?php echo VIETQR_ACCOUNT_NAME; ?></p>
            <p><strong>Số tài khoản:</strong> <?php echo VIETQR_ACCOUNT_NO; ?></p>
            <p><strong>Nội dung chuyển khoản:</strong> <span style="color: #28a745; font-weight: bold;"><?php echo $topup['transaction_code']; ?></span></p>
        </div>
        
        <div class="instructions">
            <h3><i class="fa-solid fa-info-circle"></i> Hướng dẫn nạp tiền</h3>
            <ol>
                <li>Mở ứng dụng ngân hàng của bạn</li>
                <li>Chọn chức năng quét mã QR</li>
                <li>Quét mã QR ở trên</li>
                <li>Kiểm tra thông tin và xác nhận chuyển khoản</li>
                <li>Sau khi chuyển khoản thành công, hệ thống sẽ tự động cập nhật số dư</li>
            </ol>
            <p style="color: #28a745; font-weight: bold; margin-top: 15px;">
                <i class="fa-solid fa-check-circle"></i> 
                Lưu ý: Vui lòng giữ nguyên nội dung chuyển khoản để hệ thống tự động xác nhận
            </p>
        </div>
        
        <div style="margin-top: 30px;">
            <button onclick="checkPayment()" class="btn-check">
                <i class="fa-solid fa-check-circle"></i> Tôi đã chuyển khoản
            </button>
            <a href="/topup.php">
                <button class="btn-back">
                    <i class="fa-solid fa-arrow-left"></i> Quay lại
                </button>
            </a>
        </div>
    </div>
</div>

<script>
    function checkPayment() {
        alert('Cảm ơn bạn! Giao dịch của bạn đang được xử lý.\n\nHệ thống sẽ tự động cập nhật số dư khi nhận được thanh toán.\nBạn có thể kiểm tra lịch sử nạp tiền trong trang "Nạp tiền".');
        window.location.href = '/topup.php';
    }
</script>

<?php require_once __DIR__ . '/../../../includes/footer.php'; ?>
