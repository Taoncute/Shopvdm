<?php
$pageTitle = 'Thông tin tài khoản';
require_once __DIR__ . '/../../../includes/header.php';
?>

<style>
    .profile-container {
        max-width: 800px;
        margin: 30px auto;
    }
    .profile-card {
        background: white;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
    }
    .profile-card h2 {
        color: #007bff;
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 2px solid #007bff;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #333;
    }
    .form-group input {
        width: 100%;
        padding: 12px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-size: 14px;
        box-sizing: border-box;
    }
    .form-group input:focus {
        outline: none;
        border-color: #007bff;
    }
    .btn {
        padding: 12px 30px;
        background: #007bff;
        color: white;
        border: none;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.3s ease;
    }
    .btn:hover {
        background: #0056b3;
    }
    .info-display {
        background: #f8f9fa;
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
    }
    .info-display p {
        margin: 10px 0;
        font-size: 16px;
    }
    .info-display strong {
        color: #007bff;
    }
</style>

<div class="profile-container">
    <h1><i class="fa-solid fa-user-circle"></i> Thông tin tài khoản</h1>
    
    <div class="profile-card">
        <h2><i class="fa-solid fa-info-circle"></i> Thông tin cơ bản</h2>
        <div class="info-display">
            <p><strong>Tên đăng nhập:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
            <p><strong>Số dư:</strong> <span style="color: #28a745; font-size: 20px; font-weight: bold;">
                <?php echo number_format($user['balance'], 0, ',', '.'); ?>đ
            </span></p>
            <p><strong>Vai trò:</strong> <?php echo $user['role'] === 'admin' ? 'Quản trị viên' : 'Người dùng'; ?></p>
            <p><strong>Ngày đăng ký:</strong> <?php echo date('d/m/Y H:i', strtotime($user['created_at'])); ?></p>
        </div>
    </div>
    
    <div class="profile-card">
        <h2><i class="fa-solid fa-edit"></i> Cập nhật thông tin</h2>
        <form action="/profile.php" method="POST">
            <div class="form-group">
                <label for="full_name"><i class="fa-solid fa-id-card"></i> Họ và tên</label>
                <input type="text" id="full_name" name="full_name" 
                       value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="email"><i class="fa-solid fa-envelope"></i> Email</label>
                <input type="email" id="email" name="email" 
                       value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="telegram_chat_id"><i class="fa-brands fa-telegram"></i> Telegram Chat ID</label>
                <input type="text" id="telegram_chat_id" name="telegram_chat_id" 
                       value="<?php echo htmlspecialchars($user['telegram_chat_id'] ?? ''); ?>"
                       placeholder="Nhập Chat ID để nhận thông báo qua Telegram">
            </div>
            
            <button type="submit" class="btn">
                <i class="fa-solid fa-save"></i> Lưu thay đổi
            </button>
        </form>
    </div>
    
    <div class="profile-card">
        <h2><i class="fa-solid fa-lock"></i> Đổi mật khẩu</h2>
        <form action="/profile.php" method="POST">
            <input type="hidden" name="action" value="change_password">
            
            <div class="form-group">
                <label for="current_password"><i class="fa-solid fa-key"></i> Mật khẩu hiện tại</label>
                <input type="password" id="current_password" name="current_password" required>
            </div>
            
            <div class="form-group">
                <label for="new_password"><i class="fa-solid fa-lock"></i> Mật khẩu mới</label>
                <input type="password" id="new_password" name="new_password" required minlength="6">
            </div>
            
            <div class="form-group">
                <label for="confirm_password"><i class="fa-solid fa-lock"></i> Xác nhận mật khẩu mới</label>
                <input type="password" id="confirm_password" name="confirm_password" required minlength="6">
            </div>
            
            <button type="submit" class="btn">
                <i class="fa-solid fa-save"></i> Đổi mật khẩu
            </button>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../../../includes/footer.php'; ?>
