<?php
$pageTitle = 'Đơn hàng của tôi';
require_once __DIR__ . '/../../../includes/header.php';
?>

<style>
    .orders-container {
        max-width: 1200px;
        margin: 30px auto;
    }
    .orders-table {
        width: 100%;
        background: white;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    .orders-table table {
        width: 100%;
        border-collapse: collapse;
    }
    .orders-table th {
        background: #007bff;
        color: white;
        padding: 15px;
        text-align: left;
    }
    .orders-table td {
        padding: 15px;
        border-bottom: 1px solid #eee;
    }
    .orders-table tr:last-child td {
        border-bottom: none;
    }
    .status-badge {
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: bold;
        display: inline-block;
    }
    .status-pending {
        background: #fff3cd;
        color: #856404;
    }
    .status-completed {
        background: #d4edda;
        color: #155724;
    }
    .status-failed {
        background: #f8d7da;
        color: #721c24;
    }
    .status-cancelled {
        background: #e2e3e5;
        color: #383d41;
    }
    .btn-view {
        background: #007bff;
        color: white;
        padding: 8px 15px;
        border-radius: 6px;
        text-decoration: none;
        font-size: 14px;
        display: inline-block;
        transition: background 0.3s ease;
    }
    .btn-view:hover {
        background: #0056b3;
    }
    .empty-orders {
        text-align: center;
        padding: 60px 20px;
        background: white;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    .empty-orders i {
        font-size: 64px;
        color: #ccc;
        margin-bottom: 20px;
    }
</style>

<div class="orders-container">
    <h1><i class="fa-solid fa-history"></i> Đơn hàng của tôi</h1>
    
    <?php if (empty($orders)): ?>
        <div class="empty-orders">
            <i class="fa-solid fa-box-open"></i>
            <h2>Chưa có đơn hàng nào</h2>
            <p>Bạn chưa có đơn hàng nào. Hãy bắt đầu mua sắm!</p>
            <a href="/products.php" style="display: inline-block; margin-top: 20px; padding: 12px 30px; background: #007bff; color: white; text-decoration: none; border-radius: 8px;">
                <i class="fa-solid fa-shopping-bag"></i> Mua sắm ngay
            </a>
        </div>
    <?php else: ?>
        <div class="orders-table">
            <table>
                <thead>
                    <tr>
                        <th>Mã đơn hàng</th>
                        <th>Tổng tiền</th>
                        <th>Phương thức</th>
                        <th>Trạng thái</th>
                        <th>Thời gian</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><code><?php echo htmlspecialchars($order['order_code']); ?></code></td>
                            <td><strong><?php echo number_format($order['total_amount'], 0, ',', '.'); ?>đ</strong></td>
                            <td>
                                <?php 
                                echo $order['payment_method'] === 'balance' 
                                    ? '<i class="fa-solid fa-wallet"></i> Số dư' 
                                    : '<i class="fa-solid fa-qrcode"></i> VietQR'; 
                                ?>
                            </td>
                            <td>
                                <?php
                                $statusClass = 'status-' . $order['payment_status'];
                                $statusText = [
                                    'pending' => 'Chờ thanh toán',
                                    'completed' => 'Hoàn thành',
                                    'failed' => 'Thất bại',
                                    'cancelled' => 'Đã hủy'
                                ];
                                ?>
                                <span class="status-badge <?php echo $statusClass; ?>">
                                    <?php echo $statusText[$order['payment_status']] ?? $order['payment_status']; ?>
                                </span>
                            </td>
                            <td><?php echo date('d/m/Y H:i', strtotime($order['created_at'])); ?></td>
                            <td>
                                <a href="/orders.php?id=<?php echo $order['id']; ?>" class="btn-view">
                                    <i class="fa-solid fa-eye"></i> Xem
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../../includes/footer.php'; ?>
