<?php
$pageTitle = 'Chi tiết đơn hàng';
require_once __DIR__ . '/../../../includes/header.php';
?>

<style>
    .order-container {
        max-width: 900px;
        margin: 30px auto;
    }
    .order-card {
        background: white;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
    }
    .order-card h2 {
        color: #007bff;
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 2px solid #007bff;
    }
    .order-info {
        background: #f8f9fa;
        padding: 20px;
        border-radius: 8px;
        margin-bottom: 20px;
    }
    .order-info p {
        margin: 10px 0;
        font-size: 16px;
    }
    .order-info strong {
        color: #007bff;
        min-width: 150px;
        display: inline-block;
    }
    .status-badge {
        padding: 8px 16px;
        border-radius: 20px;
        font-size: 14px;
        font-weight: bold;
        display: inline-block;
    }
    .status-pending {
        background: #fff3cd;
        color: #856404;
    }
    .status-completed {
        background: #d4edda;
        color: #155724;
    }
    .status-failed {
        background: #f8d7da;
        color: #721c24;
    }
    .order-item {
        display: flex;
        align-items: center;
        padding: 15px;
        border-bottom: 1px solid #eee;
    }
    .order-item:last-child {
        border-bottom: none;
    }
    .order-item img {
        width: 80px;
        height: 80px;
        object-fit: cover;
        border-radius: 8px;
        margin-right: 20px;
    }
    .order-item-info {
        flex: 1;
    }
    .order-item-price {
        font-weight: bold;
        color: #007bff;
        font-size: 18px;
    }
    .total-row {
        display: flex;
        justify-content: space-between;
        font-size: 24px;
        font-weight: bold;
        color: #007bff;
        margin: 20px 0;
        padding-top: 20px;
        border-top: 2px solid #007bff;
    }
    .download-btn {
        background: #28a745;
        color: white;
        padding: 10px 20px;
        border-radius: 6px;
        text-decoration: none;
        font-size: 14px;
        display: inline-block;
        margin-top: 10px;
        transition: background 0.3s ease;
    }
    .download-btn:hover {
        background: #218838;
    }
    .btn-back {
        background: #6c757d;
        color: white;
        padding: 12px 30px;
        border-radius: 8px;
        text-decoration: none;
        font-size: 16px;
        display: inline-block;
        transition: background 0.3s ease;
    }
    .btn-back:hover {
        background: #5a6268;
    }
</style>

<div class="order-container">
    <h1><i class="fa-solid fa-file-invoice"></i> Chi tiết đơn hàng</h1>
    
    <div class="order-card">
        <h2><i class="fa-solid fa-info-circle"></i> Thông tin đơn hàng</h2>
        <div class="order-info">
            <p><strong>Mã đơn hàng:</strong> <code><?php echo htmlspecialchars($order['order_code']); ?></code></p>
            <p><strong>Trạng thái:</strong> 
                <?php
                $statusClass = 'status-' . $order['payment_status'];
                $statusText = [
                    'pending' => 'Chờ thanh toán',
                    'completed' => 'Hoàn thành',
                    'failed' => 'Thất bại',
                    'cancelled' => 'Đã hủy'
                ];
                ?>
                <span class="status-badge <?php echo $statusClass; ?>">
                    <?php echo $statusText[$order['payment_status']] ?? $order['payment_status']; ?>
                </span>
            </p>
            <p><strong>Phương thức thanh toán:</strong> 
                <?php 
                echo $order['payment_method'] === 'balance' 
                    ? '<i class="fa-solid fa-wallet"></i> Thanh toán bằng số dư' 
                    : '<i class="fa-solid fa-qrcode"></i> Thanh toán qua VietQR'; 
                ?>
            </p>
            <p><strong>Thời gian đặt hàng:</strong> <?php echo date('d/m/Y H:i:s', strtotime($order['created_at'])); ?></p>
        </div>
    </div>
    
    <div class="order-card">
        <h2><i class="fa-solid fa-box"></i> Sản phẩm</h2>
        <?php foreach ($items as $item): ?>
            <div class="order-item">
                <img src="/assets/<?php echo htmlspecialchars($item['image']); ?>" 
                     alt="<?php echo htmlspecialchars($item['product_name']); ?>">
                <div class="order-item-info">
                    <strong style="font-size: 18px;"><?php echo htmlspecialchars($item['product_name']); ?></strong>
                    <div style="margin-top: 5px; color: #666;">
                        Số lượng: <?php echo $item['quantity']; ?> × 
                        <?php echo number_format($item['product_price'], 0, ',', '.'); ?>đ
                    </div>
                    <?php if ($order['payment_status'] === 'completed' && !empty($item['download_url'])): ?>
                        <a href="<?php echo htmlspecialchars($item['download_url']); ?>" 
                           target="_blank" class="download-btn">
                            <i class="fa-solid fa-download"></i> Tải xuống
                        </a>
                    <?php endif; ?>
                </div>
                <div class="order-item-price">
                    <?php echo number_format($item['subtotal'], 0, ',', '.'); ?>đ
                </div>
            </div>
        <?php endforeach; ?>
        
        <div class="total-row">
            <span>Tổng cộng:</span>
            <span><?php echo number_format($order['total_amount'], 0, ',', '.'); ?>đ</span>
        </div>
    </div>
    
    <?php if ($order['payment_status'] === 'pending' && $order['payment_method'] === 'vietqr'): ?>
        <div class="order-card" style="text-align: center;">
            <h2><i class="fa-solid fa-qrcode"></i> Thanh toán đơn hàng</h2>
            <p style="margin: 20px 0;">Đơn hàng chưa được thanh toán. Vui lòng quét mã QR để hoàn tất.</p>
            <a href="/payment.php?order_id=<?php echo $order['id']; ?>" 
               style="display: inline-block; padding: 15px 40px; background: #28a745; color: white; text-decoration: none; border-radius: 8px; font-size: 18px; font-weight: bold;">
                <i class="fa-solid fa-qrcode"></i> Xem mã QR thanh toán
            </a>
        </div>
    <?php endif; ?>
    
    <div style="text-align: center; margin-top: 30px;">
        <a href="/orders.php" class="btn-back">
            <i class="fa-solid fa-arrow-left"></i> Quay lại danh sách đơn hàng
        </a>
    </div>
</div>

<?php require_once __DIR__ . '/../../../includes/footer.php'; ?>
