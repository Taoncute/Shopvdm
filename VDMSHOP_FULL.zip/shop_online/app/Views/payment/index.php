<?php
$pageTitle = 'Thanh toán';
require_once __DIR__ . '/../../../includes/header.php';

if (!Session::isLoggedIn()) {
    header('Location: /login.php');
    exit;
}

if (!isset($_GET['order_id'])) {
    header('Location: /orders.php');
    exit;
}

require_once __DIR__ . '/../../Models/Order.php';
$orderModel = new Order();
$order = $orderModel->findById($_GET['order_id']);

if (!$order || $order['user_id'] != Session::getUserId()) {
    Session::setFlash('error', 'Đơn hàng không tồn tại');
    header('Location: /orders.php');
    exit;
}

$items = $orderModel->getOrderItems($order['id']);
?>

<style>
    .payment-container {
        max-width: 700px;
        margin: 30px auto;
    }
    .payment-card {
        background: white;
        padding: 40px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        text-align: center;
    }
    .payment-card h2 {
        color: #007bff;
        margin-bottom: 20px;
    }
    .qr-code {
        max-width: 400px;
        width: 100%;
        margin: 20px auto;
        border: 3px solid #007bff;
        border-radius: 12px;
        padding: 10px;
        background: white;
    }
    .qr-code img {
        width: 100%;
        border-radius: 8px;
    }
    .payment-info {
        background: #f8f9fa;
        padding: 20px;
        border-radius: 8px;
        margin: 20px 0;
        text-align: left;
    }
    .payment-info p {
        margin: 10px 0;
        font-size: 16px;
    }
    .payment-info strong {
        color: #007bff;
    }
    .order-code {
        font-size: 24px;
        font-weight: bold;
        color: #dc3545;
        padding: 15px;
        background: #fff3cd;
        border-radius: 8px;
        margin: 20px 0;
    }
    .instructions {
        background: #e7f3ff;
        padding: 20px;
        border-radius: 8px;
        margin: 20px 0;
        text-align: left;
    }
    .instructions h3 {
        color: #007bff;
        margin-bottom: 15px;
    }
    .instructions ol {
        margin-left: 20px;
    }
    .instructions li {
        margin: 10px 0;
        line-height: 1.6;
    }
    .btn-check {
        padding: 15px 40px;
        background: #28a745;
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        margin: 10px;
        transition: background 0.3s ease;
    }
    .btn-check:hover {
        background: #218838;
    }
    .btn-cancel {
        padding: 15px 40px;
        background: #dc3545;
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        margin: 10px;
        transition: background 0.3s ease;
    }
    .btn-cancel:hover {
        background: #c82333;
    }
</style>

<div class="payment-container">
    <div class="payment-card">
        <h1><i class="fa-solid fa-qrcode"></i> Quét mã QR để thanh toán</h1>
        
        <div class="qr-code">
            <img src="<?php echo htmlspecialchars($order['qr_code_url']); ?>" 
                 alt="QR Code thanh toán">
        </div>
        
        <div class="order-code">
            Mã đơn hàng: <?php echo htmlspecialchars($order['order_code']); ?>
        </div>
        
        <div class="payment-info">
            <p><strong>Số tiền:</strong> <?php echo number_format($order['total_amount'], 0, ',', '.'); ?>đ</p>
            <p><strong>Ngân hàng:</strong> <?php echo VIETQR_ACCOUNT_NAME; ?></p>
            <p><strong>Số tài khoản:</strong> <?php echo VIETQR_ACCOUNT_NO; ?></p>
            <p><strong>Nội dung chuyển khoản:</strong> <span style="color: #dc3545; font-weight: bold;"><?php echo $order['order_code']; ?></span></p>
        </div>
        
        <div class="instructions">
            <h3><i class="fa-solid fa-info-circle"></i> Hướng dẫn thanh toán</h3>
            <ol>
                <li>Mở ứng dụng ngân hàng của bạn</li>
                <li>Chọn chức năng quét mã QR</li>
                <li>Quét mã QR ở trên</li>
                <li>Kiểm tra thông tin và xác nhận thanh toán</li>
                <li>Sau khi chuyển khoản thành công, nhấn nút "Tôi đã thanh toán" bên dưới</li>
            </ol>
            <p style="color: #dc3545; font-weight: bold; margin-top: 15px;">
                <i class="fa-solid fa-exclamation-triangle"></i> 
                Lưu ý: Vui lòng giữ nguyên nội dung chuyển khoản để hệ thống tự động xác nhận đơn hàng
            </p>
        </div>
        
        <div style="margin-top: 30px;">
            <button onclick="checkPayment()" class="btn-check">
                <i class="fa-solid fa-check-circle"></i> Tôi đã thanh toán
            </button>
            <a href="/orders.php">
                <button class="btn-cancel">
                    <i class="fa-solid fa-arrow-left"></i> Quay lại đơn hàng
                </button>
            </a>
        </div>
    </div>
</div>

<script>
    function checkPayment() {
        // In production, this should check with backend API
        alert('Cảm ơn bạn! Đơn hàng của bạn đang được xử lý.\n\nHệ thống sẽ tự động xác nhận khi nhận được thanh toán.\nBạn có thể kiểm tra trạng thái đơn hàng trong mục "Đơn hàng".');
        window.location.href = '/orders.php?id=<?php echo $order['id']; ?>';
    }
</script>

<?php require_once __DIR__ . '/../../../includes/footer.php'; ?>
