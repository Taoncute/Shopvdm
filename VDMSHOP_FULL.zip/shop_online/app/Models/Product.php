<?php
class Product {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function getAll($filters = []) {
        $sql = "SELECT p.*, c.name as category_name FROM products p 
                LEFT JOIN categories c ON p.category_id = c.id 
                WHERE p.status = 'active'";
        
        $params = [];
        
        if (isset($filters['type'])) {
            if ($filters['type'] === 'free') {
                $sql .= " AND p.is_free = 1";
            } elseif ($filters['type'] === 'paid') {
                $sql .= " AND p.is_free = 0";
            }
        }
        
        if (isset($filters['category_id'])) {
            $sql .= " AND p.category_id = :category_id";
            $params[':category_id'] = $filters['category_id'];
        }
        
        if (isset($filters['search'])) {
            $sql .= " AND (p.name LIKE :search OR p.description LIKE :search)";
            $params[':search'] = '%' . $filters['search'] . '%';
        }
        
        $sql .= " ORDER BY p.created_at DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    public function findById($id) {
        $stmt = $this->db->prepare("
            SELECT p.*, c.name as category_name 
            FROM products p 
            LEFT JOIN categories c ON p.category_id = c.id 
            WHERE p.id = :id
        ");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }
    
    public function create($data) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO products (category_id, name, description, price, image, stock, is_free, download_url, status)
                VALUES (:category_id, :name, :description, :price, :image, :stock, :is_free, :download_url, :status)
            ");
            
            $stmt->execute([
                ':category_id' => $data['category_id'] ?? null,
                ':name' => $data['name'],
                ':description' => $data['description'] ?? '',
                ':price' => $data['price'],
                ':image' => $data['image'] ?? '',
                ':stock' => $data['stock'] ?? 999,
                ':is_free' => $data['is_free'] ?? 0,
                ':download_url' => $data['download_url'] ?? '',
                ':status' => $data['status'] ?? 'active'
            ]);
            
            return $this->db->lastInsertId();
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function update($id, $data) {
        try {
            $fields = [];
            $params = [':id' => $id];
            
            if (isset($data['category_id'])) {
                $fields[] = "category_id = :category_id";
                $params[':category_id'] = $data['category_id'];
            }
            
            if (isset($data['name'])) {
                $fields[] = "name = :name";
                $params[':name'] = $data['name'];
            }
            
            if (isset($data['description'])) {
                $fields[] = "description = :description";
                $params[':description'] = $data['description'];
            }
            
            if (isset($data['price'])) {
                $fields[] = "price = :price";
                $params[':price'] = $data['price'];
            }
            
            if (isset($data['image'])) {
                $fields[] = "image = :image";
                $params[':image'] = $data['image'];
            }
            
            if (isset($data['stock'])) {
                $fields[] = "stock = :stock";
                $params[':stock'] = $data['stock'];
            }
            
            if (isset($data['is_free'])) {
                $fields[] = "is_free = :is_free";
                $params[':is_free'] = $data['is_free'];
            }
            
            if (isset($data['download_url'])) {
                $fields[] = "download_url = :download_url";
                $params[':download_url'] = $data['download_url'];
            }
            
            if (isset($data['status'])) {
                $fields[] = "status = :status";
                $params[':status'] = $data['status'];
            }
            
            if (empty($fields)) {
                return false;
            }
            
            $sql = "UPDATE products SET " . implode(', ', $fields) . " WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function delete($id) {
        try {
            $stmt = $this->db->prepare("DELETE FROM products WHERE id = :id");
            $stmt->execute([':id' => $id]);
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function updateStock($productId, $quantity, $operation = 'decrease') {
        try {
            if ($operation === 'decrease') {
                $stmt = $this->db->prepare("
                    UPDATE products SET stock = stock - :quantity WHERE id = :id AND stock >= :quantity
                ");
            } else {
                $stmt = $this->db->prepare("
                    UPDATE products SET stock = stock + :quantity WHERE id = :id
                ");
            }
            
            $stmt->execute([
                ':quantity' => $quantity,
                ':id' => $productId
            ]);
            
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            return false;
        }
    }
}
