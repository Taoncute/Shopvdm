<?php
class Topup {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function create($userId, $amount) {
        try {
            // Generate unique transaction code
            $transactionCode = 'SHOP_TOPUP_' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 10));
            
            $stmt = $this->db->prepare("
                INSERT INTO topup_transactions (user_id, transaction_code, amount, payment_status, payment_content)
                VALUES (:user_id, :transaction_code, :amount, 'pending', :payment_content)
            ");
            
            $stmt->execute([
                ':user_id' => $userId,
                ':transaction_code' => $transactionCode,
                ':amount' => $amount,
                ':payment_content' => $transactionCode
            ]);
            
            return [
                'id' => $this->db->lastInsertId(),
                'transaction_code' => $transactionCode
            ];
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function findById($id) {
        $stmt = $this->db->prepare("
            SELECT t.*, u.username, u.email 
            FROM topup_transactions t
            JOIN users u ON t.user_id = u.id
            WHERE t.id = :id
        ");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }
    
    public function findByTransactionCode($transactionCode) {
        $stmt = $this->db->prepare("SELECT * FROM topup_transactions WHERE transaction_code = :transaction_code");
        $stmt->execute([':transaction_code' => $transactionCode]);
        return $stmt->fetch();
    }
    
    public function getUserTopups($userId) {
        $stmt = $this->db->prepare("
            SELECT * FROM topup_transactions WHERE user_id = :user_id ORDER BY created_at DESC
        ");
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetchAll();
    }
    
    public function getAllTopups() {
        $stmt = $this->db->query("
            SELECT t.*, u.username 
            FROM topup_transactions t
            JOIN users u ON t.user_id = u.id
            ORDER BY t.created_at DESC
        ");
        return $stmt->fetchAll();
    }
    
    public function updatePaymentStatus($id, $status) {
        try {
            $stmt = $this->db->prepare("
                UPDATE topup_transactions SET payment_status = :status WHERE id = :id
            ");
            $stmt->execute([
                ':status' => $status,
                ':id' => $id
            ]);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function updateQRCode($id, $qrCodeUrl) {
        try {
            $stmt = $this->db->prepare("
                UPDATE topup_transactions SET qr_code_url = :qr_code_url WHERE id = :id
            ");
            $stmt->execute([
                ':qr_code_url' => $qrCodeUrl,
                ':id' => $id
            ]);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function completeTopup($id) {
        try {
            $this->db->beginTransaction();
            
            $topup = $this->findById($id);
            
            if (!$topup || $topup['payment_status'] === 'completed') {
                $this->db->rollBack();
                return false;
            }
            
            // Update topup status
            $this->updatePaymentStatus($id, 'completed');
            
            // Update user balance
            $userModel = new User();
            $userModel->updateBalance($topup['user_id'], $topup['amount'], 'add');
            
            $this->db->commit();
            return true;
        } catch (PDOException $e) {
            $this->db->rollBack();
            return false;
        }
    }
}
