<?php
class Category {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function getAll() {
        $stmt = $this->db->query("SELECT * FROM categories ORDER BY name ASC");
        return $stmt->fetchAll();
    }
    
    public function findById($id) {
        $stmt = $this->db->prepare("SELECT * FROM categories WHERE id = :id");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }
    
    public function create($name, $description = '') {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO categories (name, description) VALUES (:name, :description)
            ");
            
            $stmt->execute([
                ':name' => $name,
                ':description' => $description
            ]);
            
            return $this->db->lastInsertId();
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function update($id, $name, $description = '') {
        try {
            $stmt = $this->db->prepare("
                UPDATE categories SET name = :name, description = :description WHERE id = :id
            ");
            
            $stmt->execute([
                ':id' => $id,
                ':name' => $name,
                ':description' => $description
            ]);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function delete($id) {
        try {
            $stmt = $this->db->prepare("DELETE FROM categories WHERE id = :id");
            $stmt->execute([':id' => $id]);
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
}
