<?php
class Cart {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function addItem($userId, $productId, $quantity = 1) {
        try {
            // Check if item already exists in cart
            $stmt = $this->db->prepare("
                SELECT * FROM cart WHERE user_id = :user_id AND product_id = :product_id
            ");
            $stmt->execute([
                ':user_id' => $userId,
                ':product_id' => $productId
            ]);
            
            $existing = $stmt->fetch();
            
            if ($existing) {
                // Update quantity
                $stmt = $this->db->prepare("
                    UPDATE cart SET quantity = quantity + :quantity WHERE user_id = :user_id AND product_id = :product_id
                ");
                $stmt->execute([
                    ':quantity' => $quantity,
                    ':user_id' => $userId,
                    ':product_id' => $productId
                ]);
            } else {
                // Insert new item
                $stmt = $this->db->prepare("
                    INSERT INTO cart (user_id, product_id, quantity) VALUES (:user_id, :product_id, :quantity)
                ");
                $stmt->execute([
                    ':user_id' => $userId,
                    ':product_id' => $productId,
                    ':quantity' => $quantity
                ]);
            }
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function getItems($userId) {
        $stmt = $this->db->prepare("
            SELECT c.*, p.name, p.price, p.image, p.stock, p.is_free
            FROM cart c
            JOIN products p ON c.product_id = p.id
            WHERE c.user_id = :user_id
            ORDER BY c.created_at DESC
        ");
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetchAll();
    }
    
    public function updateQuantity($userId, $productId, $quantity) {
        try {
            if ($quantity <= 0) {
                return $this->removeItem($userId, $productId);
            }
            
            $stmt = $this->db->prepare("
                UPDATE cart SET quantity = :quantity WHERE user_id = :user_id AND product_id = :product_id
            ");
            $stmt->execute([
                ':quantity' => $quantity,
                ':user_id' => $userId,
                ':product_id' => $productId
            ]);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function removeItem($userId, $productId) {
        try {
            $stmt = $this->db->prepare("
                DELETE FROM cart WHERE user_id = :user_id AND product_id = :product_id
            ");
            $stmt->execute([
                ':user_id' => $userId,
                ':product_id' => $productId
            ]);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function clearCart($userId) {
        try {
            $stmt = $this->db->prepare("DELETE FROM cart WHERE user_id = :user_id");
            $stmt->execute([':user_id' => $userId]);
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function getTotal($userId) {
        $items = $this->getItems($userId);
        $total = 0;
        
        foreach ($items as $item) {
            $total += $item['price'] * $item['quantity'];
        }
        
        return $total;
    }
    
    public function getCount($userId) {
        $stmt = $this->db->prepare("
            SELECT SUM(quantity) as count FROM cart WHERE user_id = :user_id
        ");
        $stmt->execute([':user_id' => $userId]);
        $result = $stmt->fetch();
        return $result['count'] ?? 0;
    }
}
