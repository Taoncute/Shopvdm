<?php
class Order {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function create($userId, $items, $totalAmount, $paymentMethod = 'vietqr') {
        try {
            $this->db->beginTransaction();
            
            // Generate unique order code
            $orderCode = 'SHOP_ORDER_' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 10));
            
            // Create order
            $stmt = $this->db->prepare("
                INSERT INTO orders (user_id, order_code, total_amount, payment_method, payment_status, payment_content)
                VALUES (:user_id, :order_code, :total_amount, :payment_method, 'pending', :payment_content)
            ");
            
            $stmt->execute([
                ':user_id' => $userId,
                ':order_code' => $orderCode,
                ':total_amount' => $totalAmount,
                ':payment_method' => $paymentMethod,
                ':payment_content' => $orderCode
            ]);
            
            $orderId = $this->db->lastInsertId();
            
            // Create order items
            $stmt = $this->db->prepare("
                INSERT INTO order_items (order_id, product_id, product_name, product_price, quantity, subtotal)
                VALUES (:order_id, :product_id, :product_name, :product_price, :quantity, :subtotal)
            ");
            
            foreach ($items as $item) {
                $subtotal = $item['price'] * $item['quantity'];
                $stmt->execute([
                    ':order_id' => $orderId,
                    ':product_id' => $item['product_id'],
                    ':product_name' => $item['name'],
                    ':product_price' => $item['price'],
                    ':quantity' => $item['quantity'],
                    ':subtotal' => $subtotal
                ]);
            }
            
            $this->db->commit();
            
            return [
                'id' => $orderId,
                'order_code' => $orderCode
            ];
        } catch (PDOException $e) {
            $this->db->rollBack();
            return false;
        }
    }
    
    public function findById($id) {
        $stmt = $this->db->prepare("
            SELECT o.*, u.username, u.email 
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.id = :id
        ");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }
    
    public function findByOrderCode($orderCode) {
        $stmt = $this->db->prepare("SELECT * FROM orders WHERE order_code = :order_code");
        $stmt->execute([':order_code' => $orderCode]);
        return $stmt->fetch();
    }
    
    public function getOrderItems($orderId) {
        $stmt = $this->db->prepare("
            SELECT oi.*, p.image, p.download_url
            FROM order_items oi
            LEFT JOIN products p ON oi.product_id = p.id
            WHERE oi.order_id = :order_id
        ");
        $stmt->execute([':order_id' => $orderId]);
        return $stmt->fetchAll();
    }
    
    public function getUserOrders($userId) {
        $stmt = $this->db->prepare("
            SELECT * FROM orders WHERE user_id = :user_id ORDER BY created_at DESC
        ");
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetchAll();
    }
    
    public function getAllOrders() {
        $stmt = $this->db->query("
            SELECT o.*, u.username 
            FROM orders o
            JOIN users u ON o.user_id = u.id
            ORDER BY o.created_at DESC
        ");
        return $stmt->fetchAll();
    }
    
    public function updatePaymentStatus($orderId, $status) {
        try {
            $stmt = $this->db->prepare("
                UPDATE orders SET payment_status = :status WHERE id = :id
            ");
            $stmt->execute([
                ':status' => $status,
                ':id' => $orderId
            ]);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function updateQRCode($orderId, $qrCodeUrl) {
        try {
            $stmt = $this->db->prepare("
                UPDATE orders SET qr_code_url = :qr_code_url WHERE id = :id
            ");
            $stmt->execute([
                ':qr_code_url' => $qrCodeUrl,
                ':id' => $orderId
            ]);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function completeOrder($orderId) {
        try {
            $this->db->beginTransaction();
            
            // Update order status
            $this->updatePaymentStatus($orderId, 'completed');
            
            // Get order items and update product stock
            $items = $this->getOrderItems($orderId);
            $productModel = new Product();
            
            foreach ($items as $item) {
                $productModel->updateStock($item['product_id'], $item['quantity'], 'decrease');
            }
            
            $this->db->commit();
            return true;
        } catch (PDOException $e) {
            $this->db->rollBack();
            return false;
        }
    }
}
