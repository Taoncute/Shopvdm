<?php
class User {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function register($username, $email, $password, $full_name = '') {
        try {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            $stmt = $this->db->prepare("
                INSERT INTO users (username, email, password, full_name) 
                VALUES (:username, :email, :password, :full_name)
            ");
            
            $stmt->execute([
                ':username' => $username,
                ':email' => $email,
                ':password' => $hashedPassword,
                ':full_name' => $full_name
            ]);
            
            return $this->db->lastInsertId();
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function login($username, $password) {
        $stmt = $this->db->prepare("
            SELECT * FROM users 
            WHERE username = :username OR email = :username
        ");
        
        $stmt->execute([':username' => $username]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }
        
        return false;
    }
    
    public function findById($id) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE id = :id");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }
    
    public function findByUsername($username) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->execute([':username' => $username]);
        return $stmt->fetch();
    }
    
    public function findByEmail($email) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = :email");
        $stmt->execute([':email' => $email]);
        return $stmt->fetch();
    }
    
    public function updateBalance($userId, $amount, $operation = 'add') {
        try {
            if ($operation === 'add') {
                $stmt = $this->db->prepare("
                    UPDATE users SET balance = balance + :amount WHERE id = :id
                ");
            } else {
                $stmt = $this->db->prepare("
                    UPDATE users SET balance = balance - :amount WHERE id = :id
                ");
            }
            
            $stmt->execute([
                ':amount' => $amount,
                ':id' => $userId
            ]);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function getBalance($userId) {
        $stmt = $this->db->prepare("SELECT balance FROM users WHERE id = :id");
        $stmt->execute([':id' => $userId]);
        $result = $stmt->fetch();
        return $result ? $result['balance'] : 0;
    }
    
    public function updateProfile($userId, $data) {
        try {
            $fields = [];
            $params = [':id' => $userId];
            
            if (isset($data['full_name'])) {
                $fields[] = "full_name = :full_name";
                $params[':full_name'] = $data['full_name'];
            }
            
            if (isset($data['email'])) {
                $fields[] = "email = :email";
                $params[':email'] = $data['email'];
            }
            
            if (isset($data['telegram_chat_id'])) {
                $fields[] = "telegram_chat_id = :telegram_chat_id";
                $params[':telegram_chat_id'] = $data['telegram_chat_id'];
            }
            
            if (empty($fields)) {
                return false;
            }
            
            $sql = "UPDATE users SET " . implode(', ', $fields) . " WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function changePassword($userId, $newPassword) {
        try {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            
            $stmt = $this->db->prepare("
                UPDATE users SET password = :password WHERE id = :id
            ");
            
            $stmt->execute([
                ':password' => $hashedPassword,
                ':id' => $userId
            ]);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function getAllUsers() {
        $stmt = $this->db->query("SELECT id, username, email, full_name, balance, role, created_at FROM users ORDER BY created_at DESC");
        return $stmt->fetchAll();
    }
}
