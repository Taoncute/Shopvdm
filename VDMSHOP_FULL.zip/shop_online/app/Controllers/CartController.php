<?php
require_once __DIR__ . '/../Models/Cart.php';
require_once __DIR__ . '/../Models/Product.php';
require_once __DIR__ . '/../Models/Order.php';
require_once __DIR__ . '/../Models/User.php';
require_once __DIR__ . '/../Core/VietQR.php';

class CartController {
    private $cartModel;
    private $productModel;
    private $orderModel;
    private $userModel;
    
    public function __construct() {
        $this->cartModel = new Cart();
        $this->productModel = new Product();
        $this->orderModel = new Order();
        $this->userModel = new User();
    }
    
    public function index() {
        if (!Session::isLoggedIn()) {
            header('Location: /login.php');
            exit;
        }
        
        $userId = Session::getUserId();
        $items = $this->cartModel->getItems($userId);
        $total = $this->cartModel->getTotal($userId);
        
        require_once __DIR__ . '/../Views/cart/index.php';
    }
    
    public function add() {
        if (!Session::isLoggedIn()) {
            Session::setFlash('error', 'Vui lòng đăng nhập để thêm sản phẩm vào giỏ hàng');
            header('Location: /login.php');
            exit;
        }
        
        $productId = $_GET['product_id'] ?? $_POST['product_id'] ?? null;
        $quantity = $_POST['quantity'] ?? 1;
        
        if (!$productId) {
            Session::setFlash('error', 'Sản phẩm không hợp lệ');
            header('Location: /products.php');
            exit;
        }
        
        $product = $this->productModel->findById($productId);
        
        if (!$product) {
            Session::setFlash('error', 'Sản phẩm không tồn tại');
            header('Location: /products.php');
            exit;
        }
        
        if ($product['is_free']) {
            Session::setFlash('error', 'Sản phẩm miễn phí không cần thêm vào giỏ hàng');
            header('Location: /products.php');
            exit;
        }
        
        $userId = Session::getUserId();
        
        if ($this->cartModel->addItem($userId, $productId, $quantity)) {
            Session::setFlash('success', 'Đã thêm sản phẩm vào giỏ hàng');
        } else {
            Session::setFlash('error', 'Có lỗi xảy ra, vui lòng thử lại');
        }
        
        header('Location: /cart.php');
        exit;
    }
    
    public function update() {
        if (!Session::isLoggedIn() || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: /cart.php');
            exit;
        }
        
        $productId = $_POST['product_id'] ?? null;
        $quantity = $_POST['quantity'] ?? 0;
        $userId = Session::getUserId();
        
        if ($this->cartModel->updateQuantity($userId, $productId, $quantity)) {
            Session::setFlash('success', 'Đã cập nhật giỏ hàng');
        } else {
            Session::setFlash('error', 'Có lỗi xảy ra, vui lòng thử lại');
        }
        
        header('Location: /cart.php');
        exit;
    }
    
    public function remove() {
        if (!Session::isLoggedIn()) {
            header('Location: /login.php');
            exit;
        }
        
        $productId = $_GET['product_id'] ?? null;
        $userId = Session::getUserId();
        
        if ($this->cartModel->removeItem($userId, $productId)) {
            Session::setFlash('success', 'Đã xóa sản phẩm khỏi giỏ hàng');
        } else {
            Session::setFlash('error', 'Có lỗi xảy ra, vui lòng thử lại');
        }
        
        header('Location: /cart.php');
        exit;
    }
    
    public function checkout() {
        if (!Session::isLoggedIn()) {
            header('Location: /login.php');
            exit;
        }
        
        $userId = Session::getUserId();
        $items = $this->cartModel->getItems($userId);
        
        if (empty($items)) {
            Session::setFlash('error', 'Giỏ hàng trống');
            header('Location: /cart.php');
            exit;
        }
        
        $total = $this->cartModel->getTotal($userId);
        $user = $this->userModel->findById($userId);
        
        require_once __DIR__ . '/../Views/cart/checkout.php';
    }
    
    public function processCheckout() {
        if (!Session::isLoggedIn() || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: /cart.php');
            exit;
        }
        
        $userId = Session::getUserId();
        $paymentMethod = $_POST['payment_method'] ?? 'vietqr';
        
        $items = $this->cartModel->getItems($userId);
        
        if (empty($items)) {
            Session::setFlash('error', 'Giỏ hàng trống');
            header('Location: /cart.php');
            exit;
        }
        
        $total = $this->cartModel->getTotal($userId);
        
        // Create order
        $orderData = $this->orderModel->create($userId, $items, $total, $paymentMethod);
        
        if (!$orderData) {
            Session::setFlash('error', 'Có lỗi xảy ra khi tạo đơn hàng');
            header('Location: /cart.php');
            exit;
        }
        
        // Clear cart
        $this->cartModel->clearCart($userId);
        
        if ($paymentMethod === 'balance') {
            // Pay with balance
            $user = $this->userModel->findById($userId);
            
            if ($user['balance'] < $total) {
                Session::setFlash('error', 'Số dư không đủ. Vui lòng nạp thêm tiền.');
                header('Location: /topup.php');
                exit;
            }
            
            // Deduct balance
            $this->userModel->updateBalance($userId, $total, 'subtract');
            
            // Complete order
            $this->orderModel->completeOrder($orderData['id']);
            
            // Update session user data
            $user = $this->userModel->findById($userId);
            Session::set('user', $user);
            
            Session::setFlash('success', 'Thanh toán thành công!');
            header('Location: /orders.php?id=' . $orderData['id']);
            exit;
        } else {
            // Generate VietQR
            $qrUrl = VietQR::generateOrderQR($orderData['order_code'], $total);
            $this->orderModel->updateQRCode($orderData['id'], $qrUrl);
            
            // Redirect to payment page
            header('Location: /payment.php?order_id=' . $orderData['id']);
            exit;
        }
    }
}
