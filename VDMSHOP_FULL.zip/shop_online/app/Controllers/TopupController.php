<?php
require_once __DIR__ . '/../Models/Topup.php';
require_once __DIR__ . '/../Models/User.php';
require_once __DIR__ . '/../Core/VietQR.php';
require_once __DIR__ . '/../Core/TelegramBot.php';

class TopupController {
    private $topupModel;
    private $userModel;
    
    public function __construct() {
        $this->topupModel = new Topup();
        $this->userModel = new User();
    }
    
    public function index() {
        if (!Session::isLoggedIn()) {
            header('Location: /login.php');
            exit;
        }
        
        $userId = Session::getUserId();
        $user = $this->userModel->findById($userId);
        $topups = $this->topupModel->getUserTopups($userId);
        
        require_once __DIR__ . '/../Views/topup/index.php';
    }
    
    public function create() {
        if (!Session::isLoggedIn() || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: /topup.php');
            exit;
        }
        
        $amount = $_POST['amount'] ?? 0;
        
        // Validate amount
        if ($amount < 10000) {
            Session::setFlash('error', 'Số tiền nạp tối thiểu là 10,000đ');
            header('Location: /topup.php');
            exit;
        }
        
        if ($amount > 50000000) {
            Session::setFlash('error', 'Số tiền nạp tối đa là 50,000,000đ');
            header('Location: /topup.php');
            exit;
        }
        
        $userId = Session::getUserId();
        
        // Create topup transaction
        $topupData = $this->topupModel->create($userId, $amount);
        
        if (!$topupData) {
            Session::setFlash('error', 'Có lỗi xảy ra, vui lòng thử lại');
            header('Location: /topup.php');
            exit;
        }
        
        // Generate VietQR
        $qrUrl = VietQR::generateTopupQR($topupData['transaction_code'], $amount);
        $this->topupModel->updateQRCode($topupData['id'], $qrUrl);
        
        // Send Telegram notification
        $user = $this->userModel->findById($userId);
        if (!empty($user['telegram_chat_id'])) {
            $telegram = new TelegramBot();
            $telegram->sendMessage(
                $user['telegram_chat_id'],
                "💳 <b>Yêu cầu nạp tiền mới</b>\n\n" .
                "📋 Mã GD: <code>{$topupData['transaction_code']}</code>\n" .
                "💰 Số tiền: <b>" . number_format($amount, 0, ',', '.') . "đ</b>\n\n" .
                "Vui lòng quét mã QR để hoàn tất giao dịch."
            );
        }
        
        // Notify admin
        $telegram = new TelegramBot();
        $telegram->notifyAdminTopup($user['username'], $topupData['transaction_code'], $amount);
        
        // Redirect to payment page
        header('Location: /topup-payment.php?id=' . $topupData['id']);
        exit;
    }
    
    public function payment() {
        if (!Session::isLoggedIn()) {
            header('Location: /login.php');
            exit;
        }
        
        if (!isset($_GET['id'])) {
            header('Location: /topup.php');
            exit;
        }
        
        $topup = $this->topupModel->findById($_GET['id']);
        
        if (!$topup || $topup['user_id'] != Session::getUserId()) {
            Session::setFlash('error', 'Giao dịch không tồn tại');
            header('Location: /topup.php');
            exit;
        }
        
        require_once __DIR__ . '/../Views/topup/payment.php';
    }
    
    public function confirm() {
        if (!Session::isLoggedIn()) {
            header('Location: /login.php');
            exit;
        }
        
        if (!isset($_GET['id'])) {
            header('Location: /topup.php');
            exit;
        }
        
        $topupId = $_GET['id'];
        $topup = $this->topupModel->findById($topupId);
        
        if (!$topup || $topup['user_id'] != Session::getUserId()) {
            Session::setFlash('error', 'Giao dịch không tồn tại');
            header('Location: /topup.php');
            exit;
        }
        
        if ($topup['payment_status'] === 'completed') {
            Session::setFlash('info', 'Giao dịch đã được xác nhận trước đó');
            header('Location: /topup.php');
            exit;
        }
        
        // In production, verify payment with bank API here
        // For now, we'll allow manual confirmation
        
        Session::setFlash('info', 'Yêu cầu xác nhận đã được gửi. Vui lòng đợi admin xử lý.');
        header('Location: /topup.php');
        exit;
    }
}
