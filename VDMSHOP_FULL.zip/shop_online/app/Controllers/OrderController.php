<?php
require_once __DIR__ . '/../Models/Order.php';
require_once __DIR__ . '/../Models/User.php';

class OrderController {
    private $orderModel;
    private $userModel;
    
    public function __construct() {
        $this->orderModel = new Order();
        $this->userModel = new User();
    }
    
    public function index() {
        if (!Session::isLoggedIn()) {
            header('Location: /login.php');
            exit;
        }
        
        $userId = Session::getUserId();
        $orders = $this->orderModel->getUserOrders($userId);
        
        require_once __DIR__ . '/../Views/orders/index.php';
    }
    
    public function show() {
        if (!Session::isLoggedIn()) {
            header('Location: /login.php');
            exit;
        }
        
        if (!isset($_GET['id'])) {
            header('Location: /orders.php');
            exit;
        }
        
        $order = $this->orderModel->findById($_GET['id']);
        
        if (!$order || $order['user_id'] != Session::getUserId()) {
            Session::setFlash('error', 'Đơn hàng không tồn tại');
            header('Location: /orders.php');
            exit;
        }
        
        $items = $this->orderModel->getOrderItems($order['id']);
        
        require_once __DIR__ . '/../Views/orders/show.php';
    }
}
