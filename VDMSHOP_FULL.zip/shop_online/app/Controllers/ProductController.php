<?php
require_once __DIR__ . '/../Models/Product.php';
require_once __DIR__ . '/../Models/Category.php';

class ProductController {
    private $productModel;
    private $categoryModel;
    
    public function __construct() {
        $this->productModel = new Product();
        $this->categoryModel = new Category();
    }
    
    public function index() {
        $filters = [];
        
        if (isset($_GET['type'])) {
            $filters['type'] = $_GET['type'];
        }
        
        if (isset($_GET['category'])) {
            $filters['category_id'] = $_GET['category'];
        }
        
        if (isset($_GET['search'])) {
            $filters['search'] = $_GET['search'];
        }
        
        $products = $this->productModel->getAll($filters);
        $categories = $this->categoryModel->getAll();
        
        require_once __DIR__ . '/../Views/products/index.php';
    }
    
    public function show() {
        if (!isset($_GET['id'])) {
            header('Location: /products.php');
            exit;
        }
        
        $product = $this->productModel->findById($_GET['id']);
        
        if (!$product) {
            Session::setFlash('error', 'Sản phẩm không tồn tại');
            header('Location: /products.php');
            exit;
        }
        
        require_once __DIR__ . '/../Views/products/show.php';
    }
}
