<?php
require_once __DIR__ . '/../Models/User.php';

class AuthController {
    private $userModel;
    
    public function __construct() {
        $this->userModel = new User();
    }
    
    public function showLogin() {
        if (Session::isLoggedIn()) {
            header('Location: /');
            exit;
        }
        require_once __DIR__ . '/../Views/auth/login.php';
    }
    
    public function showRegister() {
        if (Session::isLoggedIn()) {
            header('Location: /');
            exit;
        }
        require_once __DIR__ . '/../Views/auth/register.php';
    }
    
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: /login.php');
            exit;
        }
        
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        $remember = isset($_POST['remember']);
        
        if (empty($username) || empty($password)) {
            Session::setFlash('error', 'Vui lòng nhập đầy đủ thông tin');
            header('Location: /login.php');
            exit;
        }
        
        $user = $this->userModel->login($username, $password);
        
        if ($user) {
            Session::set('user_id', $user['id']);
            Session::set('user', $user);
            
            if ($remember) {
                setcookie('remember_token', base64_encode($user['id'] . ':' . $user['username']), time() + (86400 * 30), '/');
            }
            
            Session::setFlash('success', 'Đăng nhập thành công!');
            
            if ($user['role'] === 'admin') {
                header('Location: /admin/');
            } else {
                header('Location: /');
            }
            exit;
        } else {
            Session::setFlash('error', 'Tên đăng nhập hoặc mật khẩu không đúng');
            header('Location: /login.php');
            exit;
        }
    }
    
    public function register() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: /register.php');
            exit;
        }
        
        $username = $_POST['username'] ?? '';
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        $full_name = $_POST['full_name'] ?? '';
        
        // Validation
        $errors = [];
        
        if (empty($username)) {
            $errors[] = 'Tên đăng nhập không được để trống';
        } elseif (strlen($username) < 3) {
            $errors[] = 'Tên đăng nhập phải có ít nhất 3 ký tự';
        } elseif ($this->userModel->findByUsername($username)) {
            $errors[] = 'Tên đăng nhập đã tồn tại';
        }
        
        if (empty($email)) {
            $errors[] = 'Email không được để trống';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Email không hợp lệ';
        } elseif ($this->userModel->findByEmail($email)) {
            $errors[] = 'Email đã được sử dụng';
        }
        
        if (empty($password)) {
            $errors[] = 'Mật khẩu không được để trống';
        } elseif (strlen($password) < 6) {
            $errors[] = 'Mật khẩu phải có ít nhất 6 ký tự';
        }
        
        if ($password !== $confirm_password) {
            $errors[] = 'Mật khẩu xác nhận không khớp';
        }
        
        if (!empty($errors)) {
            Session::setFlash('error', implode('<br>', $errors));
            header('Location: /register.php');
            exit;
        }
        
        // Register user
        $userId = $this->userModel->register($username, $email, $password, $full_name);
        
        if ($userId) {
            Session::setFlash('success', 'Đăng ký thành công! Vui lòng đăng nhập.');
            header('Location: /login.php');
        } else {
            Session::setFlash('error', 'Có lỗi xảy ra, vui lòng thử lại');
            header('Location: /register.php');
        }
        exit;
    }
    
    public function logout() {
        Session::destroy();
        setcookie('remember_token', '', time() - 3600, '/');
        header('Location: /login.php');
        exit;
    }
    
    public function profile() {
        if (!Session::isLoggedIn()) {
            header('Location: /login.php');
            exit;
        }
        
        $user = $this->userModel->findById(Session::getUserId());
        require_once __DIR__ . '/../Views/user/profile.php';
    }
    
    public function updateProfile() {
        if (!Session::isLoggedIn() || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: /');
            exit;
        }
        
        $userId = Session::getUserId();
        $data = [
            'full_name' => $_POST['full_name'] ?? '',
            'email' => $_POST['email'] ?? '',
            'telegram_chat_id' => $_POST['telegram_chat_id'] ?? ''
        ];
        
        if ($this->userModel->updateProfile($userId, $data)) {
            $user = $this->userModel->findById($userId);
            Session::set('user', $user);
            Session::setFlash('success', 'Cập nhật thông tin thành công');
        } else {
            Session::setFlash('error', 'Có lỗi xảy ra, vui lòng thử lại');
        }
        
        header('Location: /profile.php');
        exit;
    }
    
    public function changePassword() {
        if (!Session::isLoggedIn() || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: /');
            exit;
        }
        
        $userId = Session::getUserId();
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        
        $user = $this->userModel->findById($userId);
        
        if (!password_verify($currentPassword, $user['password'])) {
            Session::setFlash('error', 'Mật khẩu hiện tại không đúng');
            header('Location: /profile.php');
            exit;
        }
        
        if (strlen($newPassword) < 6) {
            Session::setFlash('error', 'Mật khẩu mới phải có ít nhất 6 ký tự');
            header('Location: /profile.php');
            exit;
        }
        
        if ($newPassword !== $confirmPassword) {
            Session::setFlash('error', 'Mật khẩu xác nhận không khớp');
            header('Location: /profile.php');
            exit;
        }
        
        if ($this->userModel->changePassword($userId, $newPassword)) {
            Session::setFlash('success', 'Đổi mật khẩu thành công');
        } else {
            Session::setFlash('error', 'Có lỗi xảy ra, vui lòng thử lại');
        }
        
        header('Location: /profile.php');
        exit;
    }
}
