<?php
// Bootstrap the application
require_once __DIR__ . '/../app/Config/config.php';
require_once __DIR__ . '/../app/Core/Database.php';
require_once __DIR__ . '/../app/Core/Session.php';

Session::start();

// Auto-login from remember cookie
if (!Session::isLoggedIn() && isset($_COOKIE['remember_token'])) {
    $token = base64_decode($_COOKIE['remember_token']);
    list($userId, $username) = explode(':', $token);
    
    require_once __DIR__ . '/../app/Models/User.php';
    $userModel = new User();
    $user = $userModel->findById($userId);
    
    if ($user && $user['username'] === $username) {
        Session::set('user_id', $user['id']);
        Session::set('user', $user);
    }
}

// Simple routing
$request = $_SERVER['REQUEST_URI'];
$request = strtok($request, '?'); // Remove query string

// Route handling
switch ($request) {
    case '/':
    case '/index.php':
        header('Location: /products.php');
        exit;
        break;
        
    case '/login.php':
        require_once __DIR__ . '/../app/Controllers/AuthController.php';
        $controller = new AuthController();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $controller->login();
        } else {
            $controller->showLogin();
        }
        break;
        
    case '/register.php':
        require_once __DIR__ . '/../app/Controllers/AuthController.php';
        $controller = new AuthController();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $controller->register();
        } else {
            $controller->showRegister();
        }
        break;
        
    case '/logout.php':
        require_once __DIR__ . '/../app/Controllers/AuthController.php';
        $controller = new AuthController();
        $controller->logout();
        break;
        
    case '/profile.php':
        require_once __DIR__ . '/../app/Controllers/AuthController.php';
        $controller = new AuthController();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_POST['action']) && $_POST['action'] === 'change_password') {
                $controller->changePassword();
            } else {
                $controller->updateProfile();
            }
        } else {
            $controller->profile();
        }
        break;
        
    case '/products.php':
        require_once __DIR__ . '/../app/Controllers/ProductController.php';
        $controller = new ProductController();
        $controller->index();
        break;
        
    case '/product.php':
        require_once __DIR__ . '/../app/Controllers/ProductController.php';
        $controller = new ProductController();
        $controller->show();
        break;
        
    case '/cart.php':
        require_once __DIR__ . '/../app/Controllers/CartController.php';
        $controller = new CartController();
        $action = $_GET['action'] ?? 'index';
        switch ($action) {
            case 'add':
                $controller->add();
                break;
            case 'update':
                $controller->update();
                break;
            case 'remove':
                $controller->remove();
                break;
            default:
                $controller->index();
        }
        break;
        
    case '/checkout.php':
        require_once __DIR__ . '/../app/Controllers/CartController.php';
        $controller = new CartController();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $controller->processCheckout();
        } else {
            $controller->checkout();
        }
        break;
        
    case '/payment.php':
        require_once __DIR__ . '/../app/Views/payment/index.php';
        break;
        
    case '/orders.php':
        require_once __DIR__ . '/../app/Controllers/OrderController.php';
        $controller = new OrderController();
        if (isset($_GET['id'])) {
            $controller->show();
        } else {
            $controller->index();
        }
        break;
        
    case '/topup.php':
        require_once __DIR__ . '/../app/Controllers/TopupController.php';
        $controller = new TopupController();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $controller->create();
        } else {
            $controller->index();
        }
        break;
        
    case '/topup-payment.php':
        require_once __DIR__ . '/../app/Controllers/TopupController.php';
        $controller = new TopupController();
        $controller->payment();
        break;
        
    default:
        // Check if it's a static file request
        if (preg_match('/\.(css|js|jpg|jpeg|png|gif|ico|svg|woff|woff2|ttf)$/', $request)) {
            return false; // Let PHP's built-in server handle it
        }
        
        http_response_code(404);
        echo "<h1>404 - Page Not Found</h1>";
        break;
}
